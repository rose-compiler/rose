//
// Do not modify this file
//

#include "preferFseekToRewind.h"
typedef CompassAnalyses::PreferFseekToRewind::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
