#define KALLE(new) test
#define KALLE_DDDD test

enum Enumdecl{
   LABEL_ONE,
   LABEL_TWO
};



class Dd{

   static int* mspClassField;
   static int& msrClassField;
   static int msClassField;
   int* mpClassfield;
   int& mrClassfield;
   int mClassField;

   bool isVar;
   bool hasVar;

   void Dtest_function()
      {
	int conformsToRule;
	
      }
 
};
int main(){};
