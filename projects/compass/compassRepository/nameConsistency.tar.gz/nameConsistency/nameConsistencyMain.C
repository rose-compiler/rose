//
// Do not modify this file
//

#include "nameConsistency.h"
typedef CompassAnalyses::NameConsistency::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
