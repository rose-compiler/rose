#include <string>
#define KALLE(new) test
#define KALLE_DDDD test

enum enumdecl{
   LABEL_ONE,
   LABEL_TWO
};



class Dd{

   static int* mspClassField;
   static int& msrClassField;
   static int msClassField;
   int* mpClassfield;
   int& mrClassfield;
   int mClassField;

   void Dtest_function()
      {
	int conforms_to_rule;
	int do_not_conform;
	int conforms;
	
      }
 
};
int main(){};
