//
// Do not modify this file
//

#include "multiplePublicInheritance.h"
typedef CompassAnalyses::MultiplePublicInheritance::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
