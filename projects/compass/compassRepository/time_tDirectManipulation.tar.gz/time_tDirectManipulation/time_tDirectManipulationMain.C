//
// Do not modify this file
//

#include "time_tDirectManipulation.h"
typedef CompassAnalyses::Time_tDirectManipulation::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
