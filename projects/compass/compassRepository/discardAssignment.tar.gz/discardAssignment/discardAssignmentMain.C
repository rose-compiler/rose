//
// Do not modify this file
//

#include "discardAssignment.h"
typedef CompassAnalyses::DiscardAssignment::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
