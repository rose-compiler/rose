#include <stdlib.h>
#include <stdio.h>

int main()
{
  int r;
  r = rand();  /* generate a random integer */

  printf( "%d\n", r );

  return 0;
}
