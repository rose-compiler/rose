//
// Do not modify this file
//

#include "noRand.h"
typedef CompassAnalyses::NoRand::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
