//
// Do not modify this file
//

#include "possiblyReplicatedVariables.h"
typedef CompassAnalyses::PossiblyReplicatedVariables::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
