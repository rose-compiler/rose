//
// Do not modify this file
//

#include "preferAlgorithms.h"
typedef CompassAnalyses::PreferAlgorithms::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
