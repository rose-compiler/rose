//
// Do not modify this file
//

#include "noVariadicFunctions.h"
typedef CompassAnalyses::NoVariadicFunctions::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
