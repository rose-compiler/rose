//
// Do not modify this file
//

#include "sizeOfPointer.h"
typedef CompassAnalyses::SizeOfPointer::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
