//
// Do not modify this file
//

#include "nonVirtualRedefinition.h"
typedef CompassAnalyses::NonVirtualRedefinition::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
