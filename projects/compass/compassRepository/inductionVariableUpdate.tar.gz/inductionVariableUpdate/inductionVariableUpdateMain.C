//
// Do not modify this file
//

#include "inductionVariableUpdate.h"
typedef CompassAnalyses::InductionVariableUpdate::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
