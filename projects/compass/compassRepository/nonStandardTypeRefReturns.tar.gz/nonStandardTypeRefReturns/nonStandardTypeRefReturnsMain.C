//
// Do not modify this file
//

#include "nonStandardTypeRefReturns.h"
typedef CompassAnalyses::NonStandardTypeRefReturns::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
