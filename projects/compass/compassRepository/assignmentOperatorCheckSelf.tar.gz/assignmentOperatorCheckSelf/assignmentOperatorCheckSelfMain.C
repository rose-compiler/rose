//
// Do not modify this file
//

#include "assignmentOperatorCheckSelf.h"
typedef CompassAnalyses::AssignmentOperatorCheckSelf::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
