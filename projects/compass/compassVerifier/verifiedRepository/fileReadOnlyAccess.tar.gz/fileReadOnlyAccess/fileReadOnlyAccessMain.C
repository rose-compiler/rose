//
// Do not modify this file
//

#include "fileReadOnlyAccess.h"
typedef CompassAnalyses::FileReadOnlyAccess::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
