//
// Do not modify this file
//

#include "asynchronousSignalHandler.h"
typedef CompassAnalyses::AsynchronousSignalHandler::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
