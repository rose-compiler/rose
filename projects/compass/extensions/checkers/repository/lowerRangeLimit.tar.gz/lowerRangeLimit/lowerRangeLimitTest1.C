


int main ()
{
  int x, y;
  if (x < 2 && y <= 7)
    {
    }
}
//Your test file code goes here.

