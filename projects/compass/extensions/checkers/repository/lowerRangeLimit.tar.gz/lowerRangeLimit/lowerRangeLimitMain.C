//
// Do not modify this file
//

#include "lowerRangeLimit.h"
typedef CompassAnalyses::LowerRangeLimit::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
