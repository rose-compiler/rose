//
// Do not modify this file
//

#include "preferSetvbufToSetbuf.h"
typedef CompassAnalyses::PreferSetvbufToSetbuf::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
