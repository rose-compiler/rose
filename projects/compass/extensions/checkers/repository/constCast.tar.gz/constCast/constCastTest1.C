void foo()
{
  const int x = 2;
  int y = (int) x;
}
