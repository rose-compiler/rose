//
// Do not modify this file
//

#include "allowedFunctions.h"
typedef CompassAnalyses::AllowedFunctions::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
