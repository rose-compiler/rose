//
// Do not modify this file
//

#include "floatingPointExactComparison.h"
typedef CompassAnalyses::FloatingPointExactComparison::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
