//
// Do not modify this file
//

#include "typeTypedef.h"
typedef CompassAnalyses::TypeTypedef::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
