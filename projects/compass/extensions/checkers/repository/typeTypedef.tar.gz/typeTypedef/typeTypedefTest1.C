typedef double Real18;

void foo()
{
  double bar;
}
