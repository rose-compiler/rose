//
// Do not modify this file
//

#include "placeConstantOnTheLhs.h"
typedef CompassAnalyses::PlaceConstantOnTheLhs::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
