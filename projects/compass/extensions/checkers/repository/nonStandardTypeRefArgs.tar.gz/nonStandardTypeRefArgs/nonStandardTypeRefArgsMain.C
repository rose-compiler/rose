//
// Do not modify this file
//

#include "nonStandardTypeRefArgs.h"
typedef CompassAnalyses::NonStandardTypeRefArgs::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
