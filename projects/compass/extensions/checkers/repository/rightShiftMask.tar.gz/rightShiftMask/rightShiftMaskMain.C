//
// Do not modify this file
//

#include "rightShiftMask.h"
typedef CompassAnalyses::RightShiftMask::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
