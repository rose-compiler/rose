//
// Do not modify this file
//

#include "functionCallAllocatesMultipleResources.h"
typedef CompassAnalyses::FunctionCallAllocatesMultipleResources::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
