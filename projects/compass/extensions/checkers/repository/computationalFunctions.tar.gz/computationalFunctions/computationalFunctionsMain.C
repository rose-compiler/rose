//
// Do not modify this file
//

#include "computationalFunctions.h"
typedef CompassAnalyses::ComputationalFunctions::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
