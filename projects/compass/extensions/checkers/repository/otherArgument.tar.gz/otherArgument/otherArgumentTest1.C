class A {
  A(const A& foo);
};
