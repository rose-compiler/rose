//
// Do not modify this file
//

#include "controlVariableTestAgainstFunction.h"
typedef CompassAnalyses::ControlVariableTestAgainstFunction::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
