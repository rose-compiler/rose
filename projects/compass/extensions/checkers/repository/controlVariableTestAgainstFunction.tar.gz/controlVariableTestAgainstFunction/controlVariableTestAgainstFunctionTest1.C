
//Your test file code goes here.

int bar();

void foo()
{
  int j=2;

  for(int i = 0; i < bar(), j < 10; ++i)
  {
    j += 2;
  }

  for(int i = 0; i < 10; ++i)
  {
    j += 3;
  }
    
}
