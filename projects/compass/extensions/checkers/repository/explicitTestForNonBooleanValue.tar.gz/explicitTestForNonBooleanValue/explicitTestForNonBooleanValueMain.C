//
// Do not modify this file
//

#include "explicitTestForNonBooleanValue.h"
typedef CompassAnalyses::ExplicitTestForNonBooleanValue::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
