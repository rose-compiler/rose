//
// Do not modify this file
//

#include "constStringLiterals.h"
typedef CompassAnalyses::ConstStringLiterals::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
