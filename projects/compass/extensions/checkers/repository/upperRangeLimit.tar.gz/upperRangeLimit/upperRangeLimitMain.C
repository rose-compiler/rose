//
// Do not modify this file
//

#include "upperRangeLimit.h"
typedef CompassAnalyses::UpperRangeLimit::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
