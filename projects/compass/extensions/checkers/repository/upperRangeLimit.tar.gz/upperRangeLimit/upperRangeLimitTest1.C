

int main()
{
  int x,y;
  if (x > 2 && y >= 55)
    {
      }
return 0;
}
//Your test file code goes here.

