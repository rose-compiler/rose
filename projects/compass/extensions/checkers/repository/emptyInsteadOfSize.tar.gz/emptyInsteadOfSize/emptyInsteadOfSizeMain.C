//
// Do not modify this file
//

#include "emptyInsteadOfSize.h"
typedef CompassAnalyses::EmptyInsteadOfSize::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
