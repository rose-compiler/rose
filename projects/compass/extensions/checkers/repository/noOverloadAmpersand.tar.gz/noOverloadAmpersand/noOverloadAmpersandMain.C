//
// Do not modify this file
//

#include "noOverloadAmpersand.h"
typedef CompassAnalyses::NoOverloadAmpersand::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
