
int main()
{
  char c = (char)2;

  return;
}
