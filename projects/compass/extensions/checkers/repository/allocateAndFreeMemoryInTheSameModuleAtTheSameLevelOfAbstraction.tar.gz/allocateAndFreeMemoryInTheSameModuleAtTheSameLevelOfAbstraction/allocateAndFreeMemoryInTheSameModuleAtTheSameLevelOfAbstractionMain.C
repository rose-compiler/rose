//
// Do not modify this file
//

#include "allocateAndFreeMemoryInTheSameModuleAtTheSameLevelOfAbstraction.h"
typedef CompassAnalyses::AllocateAndFreeMemoryInTheSameModuleAtTheSameLevelOfAbstraction::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
