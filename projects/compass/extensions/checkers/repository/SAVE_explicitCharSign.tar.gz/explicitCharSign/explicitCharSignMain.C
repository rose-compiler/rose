//
// Do not modify this file
//

#include "explicitCharSign.h"
typedef CompassAnalyses::ExplicitCharSign::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
