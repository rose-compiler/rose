#include <stdio.h>

int main()
{
  char c1 = 'a';
  signed char c2 = 'b';
  unsigned char c3 = 'c';

  printf( "%c %c %c", c1, c2, c3 );

  return 0;
}
