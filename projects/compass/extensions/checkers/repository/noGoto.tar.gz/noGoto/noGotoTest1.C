void f() {
  goto label;
 label:
  return ;
}
