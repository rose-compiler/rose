//
// Do not modify this file
//

#include "duffsDevice.h"
typedef CompassAnalyses::DuffsDevice::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
