//
// Do not modify this file
//

#include "noTemplateUsage.h"
typedef CompassAnalyses::NoTemplateUsage::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
