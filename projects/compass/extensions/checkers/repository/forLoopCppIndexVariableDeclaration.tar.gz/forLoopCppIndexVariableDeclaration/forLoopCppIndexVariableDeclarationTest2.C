int main()
{
  int i = 0;
  for( i = 0; i < 100; i++ ){}
  for( int j = 0; j < 100; j++ ){}
  int k;
  for( k = 0; k < 100; k++ ) {}

  return 0;
} //main()
