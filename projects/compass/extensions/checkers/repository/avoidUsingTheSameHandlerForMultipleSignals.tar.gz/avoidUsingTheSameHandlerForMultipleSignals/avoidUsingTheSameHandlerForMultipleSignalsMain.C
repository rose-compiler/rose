//
// Do not modify this file
//

#include "avoidUsingTheSameHandlerForMultipleSignals.h"
typedef CompassAnalyses::AvoidUsingTheSameHandlerForMultipleSignals::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
