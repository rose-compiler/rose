//
// Do not modify this file
//

#include "nonAssociativeRelationalOperators.h"
typedef CompassAnalyses::NonAssociativeRelationalOperators::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
