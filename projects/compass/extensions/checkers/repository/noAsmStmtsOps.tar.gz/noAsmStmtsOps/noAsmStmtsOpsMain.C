//
// Do not modify this file
//

#include "noAsmStmtsOps.h"
typedef CompassAnalyses::NoAsmStmtsOps::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
