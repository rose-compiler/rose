//
// Do not modify this file
//

#include "floatForLoopCounter.h"
typedef CompassAnalyses::FloatForLoopCounter::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
