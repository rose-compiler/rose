//
// Do not modify this file
//

#include "setPointersToNull.h"
typedef CompassAnalyses::SetPointersToNull::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
