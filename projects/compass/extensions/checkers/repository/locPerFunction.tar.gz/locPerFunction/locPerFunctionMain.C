//
// Do not modify this file
//

#include "locPerFunction.h"
typedef CompassAnalyses::LocPerFunction::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
