//
// Do not modify this file
//

#include "newDelete.h"
typedef CompassAnalyses::NewDelete::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
