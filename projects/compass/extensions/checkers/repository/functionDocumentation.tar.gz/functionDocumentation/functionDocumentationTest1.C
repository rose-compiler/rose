
//Your test file code goes here.
void succeed() {
}

void fail() {
  //  this function has no comment in front of it
}
