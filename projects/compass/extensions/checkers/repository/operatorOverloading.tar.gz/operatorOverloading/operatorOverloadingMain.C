//
// Do not modify this file
//

#include "operatorOverloading.h"
typedef CompassAnalyses::OperatorOverloading::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
