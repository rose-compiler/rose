#include <stdlib.h>

int main()
{
  int *iptr = (int*)malloc( 256*sizeof(int) );

  return 0;
} //main()
