
//Your test file code goes here.

void pass() {

  int x;
  x=5;
  if (x>3) {

  }
}

void fail() {
  int x;
  x=5;
  if (x>3) {

  }
  if (x>3) {

  }
  if (x>3) {

  }

  if (x>3) {}
  if (x>3) {}
  if (x>3) {}
  if (x>3) {}
  if (x>3) {}
  if (x>3) {}
  if (x>3) {}
  if (x>3) {}
  if (x>3) {}
  if (x>3) {}
  if (x>3) {}
  if (x>3) {}
  if (x>3) {}
  if (x>3) {}
  if (x>3) {}
  if (x>3) {}
  if (x>3) {}
  if (x>3) {}
  if (x>3) {}
  if (x>3) {}

}
