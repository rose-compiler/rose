//
// Do not modify this file
//

#include "variableNameEqualsDatabaseName.h"
typedef CompassAnalyses::VariableNameEqualsDatabaseName::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
