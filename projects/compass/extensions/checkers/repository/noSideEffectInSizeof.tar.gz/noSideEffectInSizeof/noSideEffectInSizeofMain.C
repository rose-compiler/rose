//
// Do not modify this file
//

#include "noSideEffectInSizeof.h"
typedef CompassAnalyses::NoSideEffectInSizeof::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
