//
// Do not modify this file
//

#include "fopenFormatParameter.h"
typedef CompassAnalyses::FopenFormatParameter::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
