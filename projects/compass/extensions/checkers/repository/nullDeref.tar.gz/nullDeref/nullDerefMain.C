//
// Do not modify this file
//

#include "nullDeref.h"
typedef CompassAnalyses::NullDeref::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
