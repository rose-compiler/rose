//
// Do not modify this file
//

#include "forbiddenFunctions.h"
typedef CompassAnalyses::ForbiddenFunctions::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
