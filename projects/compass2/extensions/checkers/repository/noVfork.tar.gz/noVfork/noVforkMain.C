//
// Do not modify this file
//

#include "noVfork.h"
typedef CompassAnalyses::NoVfork::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
