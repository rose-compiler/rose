
//Your test file code goes here.

void foo()
{
	int i = 0;
	int j;
	
	(i==3) ? (j=1) : (j=2);


	j = (i==3) ? 1 : 2;

	if(i==4)
		j=3;
	else
		j=2;

	j++;
}
