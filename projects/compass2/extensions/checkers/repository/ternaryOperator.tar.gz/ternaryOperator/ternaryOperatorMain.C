//
// Do not modify this file
//

#include "ternaryOperator.h"
typedef CompassAnalyses::TernaryOperator::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
