//
// Do not modify this file
//

#include "dynamicCast.h"
typedef CompassAnalyses::DynamicCast::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
