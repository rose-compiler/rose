//
// Do not modify this file
//

#include "commaOperator.h"
typedef CompassAnalyses::CommaOperator::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
