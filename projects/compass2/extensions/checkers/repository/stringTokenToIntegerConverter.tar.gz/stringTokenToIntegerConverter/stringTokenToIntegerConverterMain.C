//
// Do not modify this file
//

#include "stringTokenToIntegerConverter.h"
typedef CompassAnalyses::StringTokenToIntegerConverter::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
