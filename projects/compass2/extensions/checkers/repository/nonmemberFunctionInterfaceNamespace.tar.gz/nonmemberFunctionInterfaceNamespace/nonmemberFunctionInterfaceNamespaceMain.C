//
// Do not modify this file
//

#include "nonmemberFunctionInterfaceNamespace.h"
typedef CompassAnalyses::NonmemberFunctionInterfaceNamespace::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
