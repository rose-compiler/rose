//
// Do not modify this file
//

#include "unaryMinus.h"
typedef CompassAnalyses::UnaryMinus::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
