//
// Do not modify this file
//

#include "oneLinePerDeclaration.h"
typedef CompassAnalyses::OneLinePerDeclaration::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
