#include <stdio.h>

int main()
{
  int i1 = 0, i2 = 0, i3 = 0;
  int i4 = 0;

  printf( "%d %d %d %d\n", i1, i2, i3, i4 );

  return 0;
}
