//
// Do not modify this file
//

#include "deepNesting.h"
typedef CompassAnalyses::DeepNesting::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
