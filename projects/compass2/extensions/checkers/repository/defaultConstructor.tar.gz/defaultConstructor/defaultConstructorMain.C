//
// Do not modify this file
//

#include "defaultConstructor.h"
typedef CompassAnalyses::DefaultConstructor::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
