//
// Do not modify this file
//

#include "cppCallsSetjmpLongjmp.h"
typedef CompassAnalyses::CppCallsSetjmpLongjmp::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
