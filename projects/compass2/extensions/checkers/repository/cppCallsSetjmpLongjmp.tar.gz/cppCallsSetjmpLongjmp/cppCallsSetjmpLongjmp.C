// -*- mode: C++; c-basic-offset: 2; indent-tabs-mode: nil -*-
// vim: expandtab:shiftwidth=2:tabstop=2

/*
 * Author: Gary M. Yuan
 * File: cppCallsSetjmpLongjmp.C 
 * Date: 19-July-2007
 * Purpose: Cpp Calls Setjmp Longjmp Analysis
 */

#include "compass.h"
#include "cppCallsSetjmpLongjmp.h"

namespace CompassAnalyses
{ 
  namespace CppCallsSetjmpLongjmp
  { 
    const std::string checkerName      = "CppCallsSetjmpLongjmp";

    // Descriptions should not include the newline character "\n".
    const std::string shortDescription = "finds calls to setjmp() or longjmp() in C++ code";
    const std::string longDescription  = "Do not use setjmp() or longjmp() in C++ code. These functions provide exception handling for C programs. These cannot be safely used in C++ code because the exception handling mechanism they implement does not adhere to normal object lifecycle semantics--a jump will not results in destruction of scoped, automatically allocated objects";
  } //End of namespace CppCallsSetjmpLongjmp.
} //End of namespace CompassAnalyses.

std::string 
CompassAnalyses::CppCallsSetjmpLongjmp::CheckerOutput::getString() const
{
  ROSE_ASSERT(getNodeArray().size() <= 1);

  // Default implementation for getString
  SgLocatedNode* locatedNode = isSgLocatedNode(getNode());
  std::string sourceCodeLocation;
  if(locatedNode != NULL)
  {
    Sg_File_Info* start = locatedNode->get_startOfConstruct();
    Sg_File_Info* end   = locatedNode->get_endOfConstruct();
    sourceCodeLocation = (end ? 
    Compass::formatStandardSourcePosition(start, end) : 
    Compass::formatStandardSourcePosition(start));        
  } //if(locatedNode != NULL)
  else
  {
    // Else this could be a SgInitializedName or SgTemplateArgument 
    //(not yet moved to be a SgLocatedNode)
    Sg_File_Info* start = getNode()->get_file_info();
    ROSE_ASSERT(start != NULL);
    sourceCodeLocation = Compass::formatStandardSourcePosition(start);
  } //else

  std::string nodeName = getNode()->class_name();
  return m_checkerName + ": " + sourceCodeLocation + ": " + nodeName + ": " 
         + m_shortDescription + " calls: " + what;
} //CompassAnalyses::CppCallsSetjmpLongjmp::CheckerOutput::getString()

CompassAnalyses::
CppCallsSetjmpLongjmp::CheckerOutput::CheckerOutput( SgNode* node, 
   const char *w )
   : OutputViolationBase(node,checkerName,shortDescription), what(w)
{
} //CompassAnalyses::CppCallsSetjmpLongjmp::CheckerOutput::CheckerOutput()

CompassAnalyses::CppCallsSetjmpLongjmp::Traversal::
Traversal(Compass::Parameters inputParameters, Compass::OutputObject* output)
   : Compass::TraversalBase(output, checkerName, shortDescription, longDescription)
{
  // Initalize checker specific parameters here, for example: 
  // YourParameter = Compass::parseInteger(inputParameters["CppCallsSetjmpLongjmp.YourParameter"]);
}

void CompassAnalyses::CppCallsSetjmpLongjmp::Traversal::visit(SgNode* node)
{ 
  SgFunctionRefExp *sgfrexp = isSgFunctionRefExp(node);

  if( sgfrexp != NULL )
  {
    if( node->get_file_info()->get_filenameString().find( ".c" ) != 
        std::string::npos )
    {
      return;
    } //if

    std::string sgfrexpName = sgfrexp->get_symbol()->get_name().getString();

    if( sgfrexpName == "_setjmp" )
    {
      output->addOutput( new CompassAnalyses::CppCallsSetjmpLongjmp::CheckerOutput::CheckerOutput( node, "setjmp()" ) );
    } //if( sgfrexpName == "_setjmp" )
    else if( sgfrexpName == "longjmp" )
    {
      output->addOutput( new CompassAnalyses::CppCallsSetjmpLongjmp::CheckerOutput::CheckerOutput( node, "longjmp()" ) );
    } //else if( sgfrexpName == "longjmp" )
  } //if( sgfrexp != NULL )

  return;
} //CompassAnalyses::CppCallsSetjmpLongjmp::Traversal::visit()
   
