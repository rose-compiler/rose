//
// Do not modify this file
//

#include "doNotUseCstyleCasts.h"
typedef CompassAnalyses::DoNotUseCstyleCasts::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
