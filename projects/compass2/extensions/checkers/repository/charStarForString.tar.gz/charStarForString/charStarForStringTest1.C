#include <string>

typedef std::string string2;

void bar(std::string arg1)
{
} //bar

int main()
{
  std::string foo1;
  std::string* foo2;
  std::string foo4[4];

  return 0;
}
