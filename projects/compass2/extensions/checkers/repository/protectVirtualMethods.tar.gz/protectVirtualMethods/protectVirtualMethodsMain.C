//
// Do not modify this file
//

#include "protectVirtualMethods.h"
typedef CompassAnalyses::ProtectVirtualMethods::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
