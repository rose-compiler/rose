//
// Do not modify this file
//

#include "doNotDeleteThis.h"
typedef CompassAnalyses::DoNotDeleteThis::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
