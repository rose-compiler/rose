int foo( int i )
{
  return i;
}

int main()
{
  return foo(0);
}
