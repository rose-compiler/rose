//
// Do not modify this file
//

#include "byteByByteStructureComparison.h"
typedef CompassAnalyses::ByteByByteStructureComparison::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
