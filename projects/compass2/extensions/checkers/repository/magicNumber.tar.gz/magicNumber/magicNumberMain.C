//
// Do not modify this file
//

#include "magicNumber.h"
typedef CompassAnalyses::MagicNumber::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
