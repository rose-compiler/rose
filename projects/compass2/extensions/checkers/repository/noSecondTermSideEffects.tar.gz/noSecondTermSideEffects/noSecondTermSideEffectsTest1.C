
//Your test file code goes here.

int main()
{
  int i;
  if ((i = 2) and false or (i &= 1))
    {
    }
}
