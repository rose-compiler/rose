//
// Do not modify this file
//

#include "noSecondTermSideEffects.h"
typedef CompassAnalyses::NoSecondTermSideEffects::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
