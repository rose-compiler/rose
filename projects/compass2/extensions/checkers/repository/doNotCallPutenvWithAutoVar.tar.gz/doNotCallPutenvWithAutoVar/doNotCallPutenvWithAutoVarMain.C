//
// Do not modify this file
//

#include "doNotCallPutenvWithAutoVar.h"
typedef CompassAnalyses::DoNotCallPutenvWithAutoVar::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
