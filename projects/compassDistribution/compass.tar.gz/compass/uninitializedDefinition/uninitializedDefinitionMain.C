//
// Do not modify this file
//

#include "uninitializedDefinition.h"
typedef CompassAnalyses::UninitializedDefinition::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
