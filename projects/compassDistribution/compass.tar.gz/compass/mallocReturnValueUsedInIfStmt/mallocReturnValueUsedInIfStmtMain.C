//
// Do not modify this file
//

#include "mallocReturnValueUsedInIfStmt.h"
typedef CompassAnalyses::MallocReturnValueUsedInIfStmt::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
