// -*- mode: C++; c-basic-offset: 2; indent-tabs-mode: nil -*-
// vim: expandtab:shiftwidth=2:tabstop=2

// Name All Parameters Analysis
// Author: Valentin  David
// Date: 03-August-2007

#include "compass.h"
#include "nameAllParameters.h"

namespace CompassAnalyses {
  namespace NameAllParameters {
    const std::string checkerName      = "NameAllParameters";

    const std::string shortDescription = "Check that all parameters are named";
    const std::string longDescription  = "This checker check that all "
    "parameters are named. If one is not used, at static_cast<void> "
    "should be used to disable compiler warnings.";
  } //End of namespace NameAllParameters.
} //End of namespace CompassAnalyses.

CompassAnalyses::NameAllParameters::
CheckerOutput::CheckerOutput(SgInitializedName* arg,
                             SgFunctionDeclaration* fun)
  : OutputViolationBase(arg, checkerName,
                        "function " + fun->get_name() +
                        " has an unamed parameter.")

{}

CompassAnalyses::NameAllParameters::Traversal::
Traversal(Compass::Parameters inputParameters, Compass::OutputObject* output)
  : Compass::TraversalBase(output, checkerName,
                           shortDescription, longDescription)
{
}

void
CompassAnalyses::NameAllParameters::Traversal::
visit(SgNode* n)
{
  SgFunctionDeclaration *decl = isSgFunctionDeclaration(n);

  if (decl != NULL) {
    SgInitializedNamePtrList args = decl->get_args();
    for (SgInitializedNamePtrList::iterator i = args.begin();
         i != args.end();
         ++i) {
      if ((*i)->get_name().str() == std::string("")) {
        output->addOutput(new CheckerOutput(*i, decl));
      }
    }
  }
} //End of the visit function.
