//
// Do not modify this file
//

#include "functionDocumentation.h"
typedef CompassAnalyses::FunctionDocumentation::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
