class A {
public:
  const void* getPointer();
};
