//
// Do not modify this file
//

#include "internalDataSharing.h"
typedef CompassAnalyses::InternalDataSharing::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
