//
// Do not modify this file
//

#include "enumDeclarationNamespaceClassScope.h"
typedef CompassAnalyses::EnumDeclarationNamespaceClassScope::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
