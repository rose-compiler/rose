//
// Do not modify this file
//

#include "friendDeclarationModifier.h"
typedef CompassAnalyses::FriendDeclarationModifier::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
