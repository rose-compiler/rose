class A { }; // good, no bases at all

class B: private A { }; // good, no public bases

class C: public A, private B { }; // good, one public base

class D: private A, private C { }; // good, no public bases

class E: public B, public D { }; // bad, two public bases

class F: public B, public D, private E { }; // bad, two public bases
