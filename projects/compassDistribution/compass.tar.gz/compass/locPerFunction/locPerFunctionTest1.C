
//Your test file code goes here.
void pass() {
  int x;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
}

void fail() {
  int x;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
  x = 5;
}
