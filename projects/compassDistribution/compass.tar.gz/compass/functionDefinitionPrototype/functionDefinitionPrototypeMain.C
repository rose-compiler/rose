//
// Do not modify this file
//

#include "functionDefinitionPrototype.h"
typedef CompassAnalyses::FunctionDefinitionPrototype::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
