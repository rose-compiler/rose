/* This information is needed for mpi.h */
#ifndef MPI_FORTDEFS
#define MPI_FORTDEFS

typedef int MPI_Fint;

#if 0
#   include "mpid_fortdefs.h"
#endif

#endif
