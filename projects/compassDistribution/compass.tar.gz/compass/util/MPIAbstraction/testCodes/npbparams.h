#define CLASS 'A'
#define NUM_PROCS 1
/*
   This file is generated automatically by the setparams utility.
   It sets the number of processors and the class of the NPB
   in this directory. Do not modify it by hand.   */
   
#define COMPILETIME "20 Apr 2007"
#define NPBVERSION "2.4"
#define MPICC "$(MY_CC)"
#define CFLAGS "$(MY_OPTFLAGS)"
#define CLINK "$(MPICC)"
#define CLINKFLAGS "(none)"
#define CMPI_LIB "$(FMPI_LIB)"
#define CMPI_INC "$(MY_MPI_INCS)"
