//
// Do not modify this file
//

#include "constCast.h"
typedef CompassAnalyses::ConstCast::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
