
//Your test file code goes here.

class Test
{
  public:
    Test();
    ~Test();
    Test operator&&(const Test &);
    Test operator||(const Test &);
    Test operator,(const Test &);
};

