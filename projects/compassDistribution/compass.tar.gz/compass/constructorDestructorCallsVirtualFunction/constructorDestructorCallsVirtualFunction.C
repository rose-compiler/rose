// -*- mode: C++; c-basic-offset: 2; indent-tabs-mode: nil -*-
// vim: expandtab:shiftwidth=2:tabstop=2

// Constructor Destructor Calls Virtual Function Analysis
// Author: Gary M. Yuan
// Date: 23-July-2007

#include "compass.h"
#include "constructorDestructorCallsVirtualFunction.h"

namespace CompassAnalyses
   { 
     namespace ConstructorDestructorCallsVirtualFunction
        { 
          const std::string checkerName      = "ConstructorDestructorCallsVirtualFunction";

       // Descriptions should not include the newline character "\n".
          const std::string shortDescription = "This checker checks if a call to a virtual function occurs in either class constructors or destructors";
          const std::string longDescription  = "";
        } //End of namespace ConstructorDestructorCallsVirtualFunction.
   } //End of namespace CompassAnalyses.

CompassAnalyses::ConstructorDestructorCallsVirtualFunction::
CheckerOutput::CheckerOutput ( SgNode* node, const char *w )
   : OutputViolationBase(node,checkerName,shortDescription), what(w)
   {}

std::string
CompassAnalyses::ConstructorDestructorCallsVirtualFunction::
CheckerOutput::getString() const
{
     ROSE_ASSERT(getNodeArray().size() <= 1);

  // Default implementation for getString
     SgLocatedNode* locatedNode = isSgLocatedNode(getNode());
     std::string sourceCodeLocation;
     if (locatedNode != NULL)
        {
          Sg_File_Info* start = locatedNode->get_startOfConstruct();
          Sg_File_Info* end   = locatedNode->get_endOfConstruct();
          sourceCodeLocation = (end ? Compass::formatStandardSourcePosition(start, end) 
                                    : Compass::formatStandardSourcePosition(start));
       }
      else
       {
      // Else this could be a SgInitializedName or SgTemplateArgument (not yet moved to be a SgLocatedNode)
         Sg_File_Info* start = getNode()->get_file_info();
         ROSE_ASSERT(start != NULL);
         sourceCodeLocation = Compass::formatStandardSourcePosition(start);
       }

     std::string nodeName = getNode()->class_name();

  // The short description used here needs to be put into a separate function (can this be part of what is filled in by the script?)
  // return loc + ": " + nodeName + ": variable requiring static constructor initialization";

     return m_checkerName + ": " + sourceCodeLocation + ": " + nodeName + ": " + m_shortDescription + "\nvirtual function call to: " + what;
}

CompassAnalyses::ConstructorDestructorCallsVirtualFunction::Traversal::
Traversal(Compass::Parameters inputParameters, Compass::OutputObject* output)
   : Compass::TraversalBase(output, checkerName, shortDescription, longDescription)
   {
  // Initalize checker specific parameters here, for example: 
  // YourParameter = Compass::parseInteger(inputParameters["ConstructorDestructorCallsVirtualFunction.YourParameter"]);


   }

void
CompassAnalyses::ConstructorDestructorCallsVirtualFunction::Traversal::
visit(SgNode* node)
   { 
     SgFunctionDefinition *fdef = isSgFunctionDefinition(node);

     if( fdef != NULL )
     {
       SgFunctionDeclaration *fdecl = fdef->get_declaration();

       if( fdecl->get_specialFunctionModifier().isConstructor() ||
           fdecl->get_specialFunctionModifier().isDestructor() )
       {
         MemberNestedTraversal nest1(output);
         nest1.traverse( node, postorder );

         FunctionNestedTraversal nest2(output);
         nest2.traverse( node, postorder ); 
       } //if( fdecl->get_specialFunctionModifier().isConstructor()... )

     } //if( fd != NULL )

     return;
   } //End of the visit function.
   
