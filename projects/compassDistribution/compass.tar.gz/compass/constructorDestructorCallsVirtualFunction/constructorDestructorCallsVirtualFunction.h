// Constructor Destructor Calls Virtual Function
// Author: Gary M. Yuan
// Date: 23-July-2007

#include "compass.h"

#ifndef COMPASS_CONSTRUCTOR_DESTRUCTOR_CALLS_VIRTUAL_FUNCTION_H
#define COMPASS_CONSTRUCTOR_DESTRUCTOR_CALLS_VIRTUAL_FUNCTION_H

namespace CompassAnalyses
   { 
     namespace ConstructorDestructorCallsVirtualFunction
        { 
          /// \brief checkerName is a std::string containing the name of this
          /// checker.
          extern const std::string checkerName;
          /// \brief shortDescription is a std::string with a short description
          /// of this checker's pattern
          extern const std::string shortDescription;
          /// \brief longDescription is a std::string with a detailed
          /// description of this checker's pattern and purpose.
          extern const std::string longDescription;

       // Specification of Checker Output Implementation
          //////////////////////////////////////////////////////////////////////          /// The CheckerOutput class implements the violation output for this
          /// checker
          //////////////////////////////////////////////////////////////////////
          class CheckerOutput: public Compass::OutputViolationBase
             {
               private:
                 const char *what;
               public:
                 CheckerOutput( SgNode*n, const char *w );
                 std::string getString() const;
             };

       // Specification of Checker Traversal Implementation
          //////////////////////////////////////////////////////////////////////
          /// The MemberNestedTraversal class performs a nested AST traversal
          /// for function calls in constructors or destructors that are
          /// member reference functions. Any virtual function calls are
          /// flagged as violations.
          //////////////////////////////////////////////////////////////////////
          class MemberNestedTraversal : public AstSimpleProcessing
          {
            private:
              Compass::OutputObject* output;
            public:
              /// The constructor
              /// \param out is a Compass::OutputObject*
              MemberNestedTraversal( Compass::OutputObject* out ) : 
                output(out){}

              /// Visit function
              /// \param n is a SgNode*
              void visit( SgNode *n )
              {
                SgMemberFunctionRefExp *call = isSgMemberFunctionRefExp(n);
  
                if( call != NULL )
                {
                  SgMemberFunctionDeclaration *decl =
                    call->get_symbol()->get_declaration();
      
                  SgFunctionModifier modifier = decl->get_functionModifier();
      
                  if( modifier.isVirtual() )
                  {
                    output->addOutput( new 
                      CheckerOutput( n, decl->get_name().getString().c_str() ) 
                    ); //output->addOutput
                  } //if( modifier.isVirtual() )
                } //if( call != NULL )
      
                return;
              } //visit( SgNode *n )
          }; //class MemberNestedTraversal

          //////////////////////////////////////////////////////////////////////
          /// The FunctionNestedTraversal class performs a nested AST
          /// traversal searching for calls to virtual functions in
          /// constructors or destructors that are not members of any class
          /// or structure. Such virtual function calls are flagged as 
          /// violations
          //////////////////////////////////////////////////////////////////////
          class FunctionNestedTraversal : public AstSimpleProcessing
          {
            private:
              Compass::OutputObject* output;
            public:
              /// The constructor
              /// \param out is a Compass::OutputObject*
              FunctionNestedTraversal( Compass::OutputObject* out ) : 
                output(out){}

              /// Visit function
              /// \param n is a SgNode*
              void visit( SgNode *n )
              {
                SgFunctionRefExp *call = isSgFunctionRefExp(n);
  
                if( call != NULL )
                {
                  SgFunctionDeclaration *decl =
                    call->get_symbol()->get_declaration();
      
                  SgFunctionModifier modifier = decl->get_functionModifier();
      
                  if( modifier.isVirtual() )
                  {
                    output->addOutput( new 
                      CheckerOutput( n, decl->get_name().getString().c_str() ) );
                  } //if( modifier.isVirtual() )
                } //if( call != NULL )
      
                return;
              } //visit( SgNode *n )
            }; //class FunctionNestedTraversal

          //////////////////////////////////////////////////////////////////////
          /// The Traversal class performs a simple AST traversal seeking out
          /// definition of class constructors and destructors
          //////////////////////////////////////////////////////////////////////
          class Traversal
             : public AstSimpleProcessing, public Compass::TraversalBase
             {
               public:
                    /// The constructor
                    /// \param inputParameters is a Compass::Parameters
                    /// \param output is a Compass::OutputObject* 
                    Traversal(Compass::Parameters inputParameters, Compass::OutputObject* output);

                 // The implementation of the run function has to match the traversal being called.
                    /// run function
                    /// \param n is a SgNode*
                    void run(SgNode* n){ this->traverse(n, preorder); };

                    /// visit function
                    /// \param n is a SgNode*
                    void visit(SgNode* n);
             };
        }
   }

// COMPASS_CONSTRUCTOR_DESTRUCTOR_CALLS_VIRTUAL_FUNCTION_H
#endif 

