//
// Do not modify this file
//

#include "assignmentReturnConstThis.h"
typedef CompassAnalyses::AssignmentReturnConstThis::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
