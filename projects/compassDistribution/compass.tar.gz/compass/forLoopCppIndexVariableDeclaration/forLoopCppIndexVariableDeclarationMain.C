//
// Do not modify this file
//

#include "forLoopCppIndexVariableDeclaration.h"
typedef CompassAnalyses::ForLoopCppIndexVariableDeclaration::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
