int main()
{
  int i = 0;
  for( i = 0; i < 100; i++ ){}

  return 0;
} //main()
