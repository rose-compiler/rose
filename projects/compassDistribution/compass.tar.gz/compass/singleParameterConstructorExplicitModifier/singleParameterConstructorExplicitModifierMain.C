//
// Do not modify this file
//

#include "singleParameterConstructorExplicitModifier.h"
typedef CompassAnalyses::SingleParameterConstructorExplicitModifier::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
