//
// Do not modify this file
//

#include "bufferOverflowFunctions.h"
typedef CompassAnalyses::BufferOverflowFunctions::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
