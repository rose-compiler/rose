// Name Consistency Analysis
// Author: Andreas Saebjoernsen
// Date: 12-July-2007

#include <string>
#include "compass.h"
#include "nameConsistencyChecker.h"
#include "checkNameImpl.h"

namespace CompassAnalyses {
  namespace NameConsistencyCheckerNamespace {
      using namespace std;

 // Specification of Checker Output Implementation

    class NameConsistencyCheckerOutput: public Compass::OutputBase {
      Sg_File_Info* file_info;
      SgNode* IRnode;
      PreprocessingInfo* preproc;

      std::string regex;
      std::string regex_name;

      public:
      NameConsistencyCheckerOutput(SgNode* n, std::string rname, std::string r)
        : IRnode(n), regex_name(rname), regex(r)
      {
         ROSE_ASSERT(n!=NULL);
         file_info= n->get_file_info();
      }

      NameConsistencyCheckerOutput(PreprocessingInfo* p, std::string rname, std::string r)
        : preproc(p), regex_name(rname), regex(r) 
      {
         ROSE_ASSERT(p!=NULL);
         file_info=p->get_file_info();

      }


      virtual std::string getCheckerName() const {
        return "NameConsistencyChecker";
      }

      virtual std::string getString() const {
        ROSE_ASSERT(file_info != NULL);
        std::string loc = Compass::formatStandardSourcePosition(file_info);

        std::string returnString =  loc + ": violates the "+ regex_name + " rule \"" + regex + "\"";
        if(preproc != NULL){
//           returnString = returnString + " : " + preproc->getString();
        }else if (IRnode != NULL){
           returnString = returnString + " : " + IRnode->unparseToString();
        }else
           exit(1); 

        return returnString;
   }

      virtual ~NameConsistencyCheckerOutput(){}
    };


 // Specification of Checker Traversal Implementation

    class NameConsistencyCheckerTraversal: public AstSimpleProcessing, public Compass::TraversalBase {
      Compass::OutputObject* output;
      //Your data structures go here.
      std::string ruleFile;
      NameEnforcer nm;
      public:
      NameConsistencyCheckerTraversal(Compass::OutputObject* output, std::string rf)
        : output(output), ruleFile(rf){
             nm.readFile(ruleFile);
 
      }

      virtual void run(SgNode* n) {
        this->traverse(n, preorder);
      }

      virtual void visit(SgNode* n) {
          //All violations to SgNode type rules
          std::list< std::pair<name_types,SgNode*> > violations;
          //All violations to rules for macros
          std::list< std::pair<name_types,PreprocessingInfo*> > macroViolations;
          //Call the function to enforce all rules found in the current rule file
          nm.enforceRules(n,violations, macroViolations);
    
          for( std::list< std::pair<name_types,SgNode*> >::iterator iItr = violations.begin();
               iItr != violations.end(); ++iItr  ){
                output->addOutput(new NameConsistencyCheckerOutput(iItr->second, nm.get_enumName(iItr->first),nm.get_reg(iItr->first) ));
          }

          for( std::list< std::pair<name_types,PreprocessingInfo*> >::iterator iItr = macroViolations.end();
               iItr != macroViolations.end(); ++iItr ){
                 output->addOutput(new NameConsistencyCheckerOutput(iItr->second, nm.get_enumName(iItr->first),nm.get_reg(iItr->first) ));
          }
       

      } //End of the visit function.

      virtual ~NameConsistencyCheckerTraversal(){}

    }; //End of class NameConsistencyCheckerTraversal

 // Specification of Checker Factory Class Implementation

    std::string NameConsistencyCheckerFactory::getName() const {
      return "Name Consistency Checker";
    }

    std::string NameConsistencyCheckerFactory::getHelp() const {
      return "Name Consistency:\n"
             "Tests if ....FILL IN YOUR STUFF HERE......  \n"
             "\n";
    }

    Compass::TraversalBase*
    NameConsistencyCheckerFactory::create(const Compass::Parameters& params, Compass::OutputObject* output) const {
      try {
        std::string fileName =
          Compass::parseString(params["NameConsistencyChecker.rulesFile"]);

        return new NameConsistencyCheckerTraversal(output, fileName);
      } catch (const Compass::ParameterNotFoundException& e) {
        std::cerr << e.what() << std::endl;
        return 0;
      } catch (const Compass::ParseError& e) {
        std::cerr << e.what() << std::endl;
        return 0;
      }
    }


  }
} //End of namespace CompassAnalyses.
