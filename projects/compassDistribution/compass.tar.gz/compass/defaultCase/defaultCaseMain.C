//
// Do not modify this file
//

#include "defaultCase.h"
typedef CompassAnalyses::DefaultCase::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
