//
// Do not modify this file
//

#include "subExpressionEvaluationOrder.h"
typedef CompassAnalyses::SubExpressionEvaluationOrder::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
