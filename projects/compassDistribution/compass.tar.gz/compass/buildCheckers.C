// This is an automatically generated file
#include <iostream>
#include <rose.h>
#include <vector>
#include "compass.h"
#include "checkers.h"

void
buildCheckers( std::vector<Compass::TraversalBase*> &retVal, Compass::Parameters &params, Compass::OutputObject &output )
{


    try {
        CompassAnalyses::AssignmentOperatorCheckSelf::Traversal *traversal;
        traversal = new CompassAnalyses::AssignmentOperatorCheckSelf::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::AssignmentReturnConstThis::Traversal *traversal;
        traversal = new CompassAnalyses::AssignmentReturnConstThis::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::BooleanIsHas::Traversal *traversal;
        traversal = new CompassAnalyses::BooleanIsHas::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::CommaOperator::Traversal *traversal;
        traversal = new CompassAnalyses::CommaOperator::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::ComputationalFunctions::Traversal *traversal;
        traversal = new CompassAnalyses::ComputationalFunctions::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::ConstCast::Traversal *traversal;
        traversal = new CompassAnalyses::ConstCast::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::ConstructorDestructorCallsVirtualFunction::Traversal *traversal;
        traversal = new CompassAnalyses::ConstructorDestructorCallsVirtualFunction::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::ControlVariableTestAgainstFunction::Traversal *traversal;
        traversal = new CompassAnalyses::ControlVariableTestAgainstFunction::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::CopyConstructorConstArg::Traversal *traversal;
        traversal = new CompassAnalyses::CopyConstructorConstArg::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::CppCallsSetjmpLongjmp::Traversal *traversal;
        traversal = new CompassAnalyses::CppCallsSetjmpLongjmp::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::CyclomaticComplexity::Traversal *traversal;
        traversal = new CompassAnalyses::CyclomaticComplexity::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::DataMemberAccess::Traversal *traversal;
        traversal = new CompassAnalyses::DataMemberAccess::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::DeepNesting::Traversal *traversal;
        traversal = new CompassAnalyses::DeepNesting::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::DefaultCase::Traversal *traversal;
        traversal = new CompassAnalyses::DefaultCase::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::DefaultConstructor::Traversal *traversal;
        traversal = new CompassAnalyses::DefaultConstructor::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::DiscardAssignment::Traversal *traversal;
        traversal = new CompassAnalyses::DiscardAssignment::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::DuffsDevice::Traversal *traversal;
        traversal = new CompassAnalyses::DuffsDevice::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::EnumDeclarationNamespaceClassScope::Traversal *traversal;
        traversal = new CompassAnalyses::EnumDeclarationNamespaceClassScope::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::ExplicitCopy::Traversal *traversal;
        traversal = new CompassAnalyses::ExplicitCopy::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::ExplicitTestForNonBooleanValue::Traversal *traversal;
        traversal = new CompassAnalyses::ExplicitTestForNonBooleanValue::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::FloatingPointExactComparison::Traversal *traversal;
        traversal = new CompassAnalyses::FloatingPointExactComparison::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::ForLoopConstructionControlStmt::Traversal *traversal;
        traversal = new CompassAnalyses::ForLoopConstructionControlStmt::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::ForLoopCppIndexVariableDeclaration::Traversal *traversal;
        traversal = new CompassAnalyses::ForLoopCppIndexVariableDeclaration::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::FriendDeclarationModifier::Traversal *traversal;
        traversal = new CompassAnalyses::FriendDeclarationModifier::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::FunctionDefinitionPrototype::Traversal *traversal;
        traversal = new CompassAnalyses::FunctionDefinitionPrototype::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::FunctionDocumentation::Traversal *traversal;
        traversal = new CompassAnalyses::FunctionDocumentation::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::InductionVariableUpdate::Traversal *traversal;
        traversal = new CompassAnalyses::InductionVariableUpdate::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::InternalDataSharing::Traversal *traversal;
        traversal = new CompassAnalyses::InternalDataSharing::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::LocalizedVariables::Traversal *traversal;
        traversal = new CompassAnalyses::LocalizedVariables::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::LocPerFunction::Traversal *traversal;
        traversal = new CompassAnalyses::LocPerFunction::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::MallocReturnValueUsedInIfStmt::Traversal *traversal;
        traversal = new CompassAnalyses::MallocReturnValueUsedInIfStmt::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::MultiplePublicInheritance::Traversal *traversal;
        traversal = new CompassAnalyses::MultiplePublicInheritance::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::NameAllParameters::Traversal *traversal;
        traversal = new CompassAnalyses::NameAllParameters::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::NoExitInMpiCode::Traversal *traversal;
        traversal = new CompassAnalyses::NoExitInMpiCode::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::NoGoto::Traversal *traversal;
        traversal = new CompassAnalyses::NoGoto::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::NonmemberFunctionInterfaceNamespace::Traversal *traversal;
        traversal = new CompassAnalyses::NonmemberFunctionInterfaceNamespace::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::NonVirtualRedefinition::Traversal *traversal;
        traversal = new CompassAnalyses::NonVirtualRedefinition::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::OperatorOverloading::Traversal *traversal;
        traversal = new CompassAnalyses::OperatorOverloading::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::OtherArgument::Traversal *traversal;
        traversal = new CompassAnalyses::OtherArgument::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::PlaceConstantOnTheLhs::Traversal *traversal;
        traversal = new CompassAnalyses::PlaceConstantOnTheLhs::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::ProtectVirtualMethods::Traversal *traversal;
        traversal = new CompassAnalyses::ProtectVirtualMethods::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::PushBack::Traversal *traversal;
        traversal = new CompassAnalyses::PushBack::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::SingleParameterConstructorExplicitModifier::Traversal *traversal;
        traversal = new CompassAnalyses::SingleParameterConstructorExplicitModifier::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::SubExpressionEvaluationOrder::Traversal *traversal;
        traversal = new CompassAnalyses::SubExpressionEvaluationOrder::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::TernaryOperator::Traversal *traversal;
        traversal = new CompassAnalyses::TernaryOperator::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::UnaryMinus::Traversal *traversal;
        traversal = new CompassAnalyses::UnaryMinus::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::UninitializedDefinition::Traversal *traversal;
        traversal = new CompassAnalyses::UninitializedDefinition::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

    try {
        CompassAnalyses::VoidStar::Traversal *traversal;
        traversal = new CompassAnalyses::VoidStar::Traversal(params, &output);
        retVal.push_back(traversal);
    } catch (const Compass::ParameterNotFoundException &e) {
        std::cerr << e.what() << std::endl;
    } catch (const Compass::ParseError &e) {
        std::cerr << e.what() << std::endl;
    }

  return;
} //buildCheckers()

