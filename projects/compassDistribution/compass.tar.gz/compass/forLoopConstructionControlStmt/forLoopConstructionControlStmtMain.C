//
// Do not modify this file
//

#include "forLoopConstructionControlStmt.h"
typedef CompassAnalyses::ForLoopConstructionControlStmt::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
