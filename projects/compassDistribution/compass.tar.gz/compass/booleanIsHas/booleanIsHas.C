// -*- mode: C++; c-basic-offset: 2; indent-tabs-mode: nil -*-
// vim: expandtab:shiftwidth=2:tabstop=2

// Boolean Is Has Analysis
// Author: pants,,,
// Date: 24-July-2007

#include "compass.h"
#include "booleanIsHas.h"

namespace CompassAnalyses
   { 
     namespace BooleanIsHas
        { 
          const std::string checkerName      = "BooleanIsHas";

       // Descriptions should not include the newline character "\n".
          const std::string shortDescription = "Finding boolean variables or boolean returning functions that do not begin with 'is_' or 'has_'";
          const std::string longDescription  = "Finds all boolean variables or boolean returning functions whose name does not begin with 'is_' or 'has_'";
        } //End of namespace BooleanIsHas.
   } //End of namespace CompassAnalyses.

CompassAnalyses::BooleanIsHas::
CheckerOutput::CheckerOutput ( SgNode* node )
   : OutputViolationBase(node,checkerName,shortDescription)
   {}

CompassAnalyses::BooleanIsHas::Traversal::
Traversal(Compass::Parameters inputParameters, Compass::OutputObject* output)
   : Compass::TraversalBase(output, checkerName, shortDescription, longDescription)
   {
  // Initalize checker specific parameters here, for example: 
  // YourParameter = Compass::parseInteger(inputParameters["BooleanIsHas.YourParameter"]);


   }

void
CompassAnalyses::BooleanIsHas::Traversal::
visit(SgNode* node)
   {
          //
          // Implement your visitor here.
          //
	std::string typeName, thingName;
        SgNode *ln;
        SgFunctionDeclaration* fn = isSgFunctionDeclaration(node);
        SgVariableDeclaration* var = isSgVariableDeclaration(node);
        if (fn)
          {
            ln = isSgNode(fn);
            thingName = fn->get_name().str();
            thingName += " is a bool-returning function";
            SgFunctionType* s = fn->get_type();
            SgType *tl = s->get_return_type();
            typeName = tl->unparseToString();
            
          }
        else if (var)
          {
            ln = isSgNode(var);
            SgInitializedNamePtrList vars =  var->get_variables();
            if (!vars.empty())
              {
                if (vars.size() > 1)
                  {
                    std::cout << "vars is bigger than 1";
                  }
                for (SgInitializedNamePtrList::iterator j = vars.begin(); j != vars.end(); j ++)
                  {
                    SgInitializedName* initName = isSgInitializedName (*j);
                    if(!initName) {return;}
                    SgType* t = initName->get_type();
                    typeName = t->unparseToString();
                    thingName  = initName->get_qualified_name().str();
                    thingName += " is a boolean variable";
                  }
              }
          }
        if (!fn and !var) return;
        if (typeName.rfind("bool",5) != std::string::npos and not (thingName.rfind("is_", 0) != std::string::npos or thingName.rfind("has_", 0) != std::string::npos))
          {
            //Sg_File_Info* start = ln->get_startOfConstruct();
          output->addOutput(new CheckerOutput(node));
          }

      
  // Implement your traversal here.  

   } //End of the visit function.
   
