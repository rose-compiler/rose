//
// Do not modify this file
//

#include "booleanIsHas.h"
typedef CompassAnalyses::BooleanIsHas::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
