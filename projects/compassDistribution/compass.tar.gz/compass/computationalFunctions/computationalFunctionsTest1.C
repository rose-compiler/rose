
//Your test file code goes here.

void pass() {
  int x= 4;
  int y = x+5+7;
}

void fail() {
  int x=4;
  int y=x+5+7;
  int *z = &x;
  y = *z+*z+6+8+9;
}
