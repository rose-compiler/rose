int x;

class X{};

X a;
X b;
X c;
X d;
X e;
X f;
X g;

void foo();

void foo()
{
}

void foobar()
{
}

void foobar_1()
{
}

void foobar_2()
{
}

void foobar_3()
{
}

void foobar_4()
{
}

void foobar_5()
{
}

void foobar_6()
{
}

void foobar_7()
{
}

void foobar_8()
{
}

void foobar_9()
{
}

void foobar_10()
{
}

void foobar_11()
{
}

void foobar_12()
{
}

int 
main(int argc, char** argv)
   {
     goto tag;
     int i = 0;
     switch(i)
        {
        }
     tag:      
     return 0;
   }
