class good 
{
  public:
    good(){}
}; //class good

class bad
{
  public:
    ~bad(){}
}; //class bad
