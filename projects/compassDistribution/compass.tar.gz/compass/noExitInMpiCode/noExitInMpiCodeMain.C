//
// Do not modify this file
//

#include "noExitInMpiCode.h"
typedef CompassAnalyses::NoExitInMpiCode::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
