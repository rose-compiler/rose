/*
 * Author: Gary M. Yuan
 * File: cppCallsSetjmpLongjmp.h
 * Date: 19-July-2007
 * Purpose: Cpp Calls Setjmp Longjmp header
 */

#include "compass.h"

#ifndef COMPASS_CPP_CALLS_SETJMP_LONGJMP_H
#define COMPASS_CPP_CALLS_SETJMP_LONGJMP_H

namespace CompassAnalyses
{ 
  namespace CppCallsSetjmpLongjmp
  { 
    /// \brief checkerName is a std::string containing the name of this checker.
    extern const std::string checkerName;
    /// \brief shortDescription is a std::string with a short description of
    /// this checker's pattern.
    extern const std::string shortDescription;
    /// \brief longDescription is a std::string with a detailed description
    /// of this checker's pattern and purpose.
    extern const std::string longDescription;

    // Specification of Checker Output Implementation
    ////////////////////////////////////////////////////////////////////////////
    /// The CheckerOutput class implements the violation output for this
    /// checker
    ////////////////////////////////////////////////////////////////////////////

    class CheckerOutput : public Compass::OutputViolationBase
    { 
      private:
        const char *what;
      public:
        std::string getString() const;
        CheckerOutput(SgNode* node, const char *w);
    }; //class CheckerOutput

    // Specification of Checker Traversal Implementation
    ////////////////////////////////////////////////////////////////////////////
    /// The NestedTraversal class implements a nested AST traversal seeking
    /// function reference expressions to setjmp() or longjmp(). These are
    /// flagged as violations of this checker.
    ////////////////////////////////////////////////////////////////////////////
    class NestedTraversal : public AstSimpleProcessing
    {
      private:
        Compass::OutputObject* output;
      public:
        NestedTraversal( Compass::OutputObject *out ) : output(out) {}
        void visit( SgNode *n );
    }; //class NestedTraversal

    ////////////////////////////////////////////////////////////////////////////
    /// The Traversal class implements a simple AST traversal seeking out 
    /// SgFile instances representing the source files of the project. SgFile
    /// nodes are checked to not contain either the 
    /// -rose:C_only or -rose:C99_only options and then performs the nested
    /// traversal at that node.
    ////////////////////////////////////////////////////////////////////////////
    class Traversal : public AstSimpleProcessing, public Compass::TraversalBase
    {
      // Checker specific parameters should be allocated here.

      public:
        /// \brief The constructor
        Traversal(Compass::Parameters inputParameters, 
                  Compass::OutputObject* output);

        // The implementation of the run function has to match the 
        //traversal being called.
        /// \brief run, starts the AST traversal
        void run(SgNode* n){ this->traverse(n, preorder); };

        /// \brief visit, pattern for AST traversal
        void visit(SgNode* n);
    }; //class Traversal
  } //namespace CppCallsSetjmpLongjmp
} //namespace CompassAnalyses

// COMPASS_CPP_CALLS_SETJMP_LONGJMP_H
#endif 
