//
// Do not modify this file
//

#include "cyclomaticComplexity.h"
typedef CompassAnalyses::CyclomaticComplexity::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
