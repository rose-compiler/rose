int f(int n)
{
    return (n++, n++, n); // not OK (twice): comma operator
}

class A;

void operator,(const A &a, const A &b); // not OK: comma operator decl

void g(const A &a)
{
    a, a; // the use of the overloaded operator is not flagged
}
