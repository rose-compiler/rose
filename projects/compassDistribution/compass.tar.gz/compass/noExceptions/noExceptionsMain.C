//
// Do not modify this file
//

#include "noExceptions.h"
typedef CompassAnalyses::NoExceptions::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
