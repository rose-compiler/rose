// -*- mode: C++; c-basic-offset: 2; indent-tabs-mode: nil -*-
// vim: expandtab:shiftwidth=2:tabstop=2

// Type Typedef Analysis
// Author: Andreas Saebjoernsen
// Date: 24-July-2007

#include "compass.h"
#include "typeTypedef.h"
#include <fstream>

using namespace std;

namespace CompassAnalyses
   {


//Will read in the file at the filename provided as an argument and
//create a map of typedef identifiers to a pair of a bool and a string.
//The bool will be true if the typedef should also be used for it's type
//with a const type modifier. The string in the pair stands for the
//type of the typedef, but that is found in the AST later.

std::map<std::string, std::pair<bool,std::string> > 
readFile( std::string filename){
     std::map<std::string, std::pair<bool,std::string> > typedefsToUse;
     std::fstream file_op(filename.c_str());
     if (file_op.fail()) {
	  std::cout << "error: could not find file \"" << filename 
	           << "\" which is meant to include the styles to enforce with " 
		   << "the name checker." << std::endl;
			          exit(1);    // abort program
				      
				  }
     std::string current_word;
     bool is_first_word = true;
  //read file
     char dummyString[2000];

     while(file_op >> current_word){
       //First word denotes what the regular expression should operate
       //upon. Second word denotes the regular expression

	     if(  current_word.substr(0,1) == std::string("#") ){
	      //Skip rest of the line if a "#" character is found. This denotes a 
	      //comment
	      file_op.getline(dummyString,2000);
	      
	     }else{
        if(current_word.substr(0,2) == "c:" ){
           typedefsToUse[current_word.substr(2)] = std::pair<bool,std::string>(true,"");
        }else{
           typedefsToUse[current_word] = std::pair<bool,std::string>(false,"");
        }
	  	 }
     }

    return typedefsToUse;
}

//Replaces all whitespaces with a char in a string
void
replaceWhitespace(std::string& inStr, char replaceWith ){
    for ( int i = 0; i < inStr.size(); ++i)
         if(inStr[i] == ' ')
          inStr[i] = replaceWith;

};


     namespace TypeTypedef
        { 
          const std::string checkerName      = "TypeTypedef";

       // Descriptions should not include the newline character "\n".
          const std::string shortDescription = "Enforces that a typedef should be used instead of a type.";
          const std::string longDescription  = "To ease maintainability some projects use typedefs for some types." 
                                               "This checker reports when the type is used instead of the typedef.";
        } //End of namespace TypeTypedef.
   } //End of namespace CompassAnalyses.

CompassAnalyses::TypeTypedef::
CheckerOutput::CheckerOutput (SgType* to, std::string isN, std::string shouldBeN, SgInitializedName* node)
        : toType(to),  IRnode(node), is(isN), shouldBe(shouldBeN),
          OutputViolationBase(node,checkerName,shortDescription)
   {}

CompassAnalyses::TypeTypedef::Traversal::
Traversal(Compass::Parameters inputParameters, Compass::OutputObject* output)
   : Compass::TraversalBase(output, checkerName, shortDescription, longDescription)
   {
  // Initalize checker specific parameters here, for example: 
  // YourParameter = Compass::parseInteger(inputParameters["TypeTypedef.YourParameter"]);
     typedefsToUse  = std::map<std::string, std::pair<bool,std::string> >();
     typeToTypedefs = std::map<std::string, std::string >();


    ruleFile = Compass::parseString(inputParameters["TypeTypedef.RulesFile"]);
    typedefsToUse = readFile(ruleFile); 
   }

std::string 
CompassAnalyses::TypeTypedef::CheckerOutput::getString() const {
        std::string loc =
           Compass::formatStandardSourcePosition(IRnode->get_file_info());

        std::string castExp = IRnode->unparseToString();

        std::string typeOfCast;
 
        return loc + ": " + castExp + ": is " +is + " should be " + shouldBe;

}

void
CompassAnalyses::TypeTypedef::Traversal::
visit(SgNode* node)
   { 
        SgVariableDeclaration* vd = isSgVariableDeclaration(node);

        //If a typedef is found fill in the values for it in the map
        //such that a type maps to it's typedef.
        if(SgTypedefDeclaration* typedefDecl = isSgTypedefDeclaration(node)){
           std::map<std::string, std::pair<bool,std::string> >::iterator iItr = typedefsToUse.find( typedefDecl->get_name().getString() );
           if( iItr != typedefsToUse.end()  ){
                iItr->second.second =typedefDecl->get_base_type()->unparseToString(); 
                replaceWhitespace(iItr->second.second,'_');
                typeToTypedefs[iItr->second.second] = iItr->first;
                if(iItr->second.first == true)
                   typeToTypedefs["const_" + iItr->second.second] = iItr->first;

           }


        }

        if(vd == NULL)
           return;

        //Find all violations of the typedef rules
        for(SgInitializedNamePtrList::iterator i = vd->get_variables().begin();
               i != vd->get_variables().end(); ++i  )
         {
           SgInitializedName* in = isSgInitializedName(*i);

           //Type casted to
           SgType* toType       = in->get_type();
           string  toTypeName   = toType->unparseToString(); //TransformationSupport::getTypeName(toType);
           replaceWhitespace(toTypeName,'_');
 
           //Create an object for the violation if there is one
           if( typeToTypedefs.find(toTypeName) != typeToTypedefs.end() ){
               getOutput()->addOutput(new CheckerOutput(toType, toTypeName, typeToTypedefs.find(toTypeName)->second , in));
           }

        }
   } //End of the visit function.
   
