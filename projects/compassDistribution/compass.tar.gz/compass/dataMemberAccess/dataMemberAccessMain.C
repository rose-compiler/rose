//
// Do not modify this file
//

#include "dataMemberAccess.h"
typedef CompassAnalyses::DataMemberAccess::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
