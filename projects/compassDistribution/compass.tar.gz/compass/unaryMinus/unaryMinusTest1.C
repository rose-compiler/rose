int f(int n, float f, unsigned int u)
{
    return -n  // OK: int is signed
         + -f  // OK: float is signed
         + -u; // not OK: unary minus on unsigned expression
}
