//
// Do not modify this file
//

#include "staticConstructorInitialization.h"
typedef CompassAnalyses::StaticConstructorInitialization::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
