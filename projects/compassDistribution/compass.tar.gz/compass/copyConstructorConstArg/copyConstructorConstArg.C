// -*- mode: C++; c-basic-offset: 2; indent-tabs-mode: nil -*-
// vim: expandtab:shiftwidth=2:tabstop=2

// Copy Constructor Const Arg Analysis
// Author: pants,,,
// Date: 24-July-2007

#include "compass.h"
#include "copyConstructorConstArg.h"

namespace CompassAnalyses
   { 
     namespace CopyConstructorConstArg
        { 
          const std::string checkerName      = "CopyConstructorConstArg";

       // Descriptions should not include the newline character "\n".
          const std::string shortDescription = "Finding copy constructors that do not take const references as arguments";
          const std::string longDescription  = "Finds copy constructors that do not take const references to class type as function parameters.";
        } //End of namespace CopyConstructorConstArg.
   } //End of namespace CompassAnalyses.

CompassAnalyses::CopyConstructorConstArg::
CheckerOutput::CheckerOutput ( SgNode* node )
   : OutputViolationBase(node,checkerName,shortDescription)
   {}

CompassAnalyses::CopyConstructorConstArg::Traversal::
Traversal(Compass::Parameters inputParameters, Compass::OutputObject* output)
   : Compass::TraversalBase(output, checkerName, shortDescription, longDescription)
   {
  // Initalize checker specific parameters here, for example: 
  // YourParameter = Compass::parseInteger(inputParameters["CopyConstructorConstArg.YourParameter"]);


   }

void
CompassAnalyses::CopyConstructorConstArg::Traversal::
visit(SgNode* node)
   { 
  // Implement your traversal here.  
     
	bool is_const = false;
	bool is_copy = false;
	bool is_ref = false;
	// is it a class? get name and list of members
	SgClassDeclaration* cs = isSgClassDeclaration(node);
	if (!cs) return;
	
	std::string className = cs->get_name().str();
	
	SgClassType* clt = cs->get_type();

	SgClassDefinition* cl = cs->get_definition();
	if (!cl) return;
	
	SgDeclarationStatementPtrList members = cl->get_members();
	for (SgDeclarationStatementPtrList::iterator i = members.begin(); i != members.end(); i ++)
	  {
	    //find member functions and check if we have a constructor
	    SgFunctionDeclaration* fn = isSgFunctionDeclaration(*i);
	    if (fn)
	      {
		std::string funcName = fn->get_name().str();
		SgSpecialFunctionModifier mods = fn->get_specialFunctionModifier();
		
		if (mods.isConstructor())
		  {
		    //get the argument list from the constructor, make sure there is one arg.
		    SgInitializedNamePtrList fnArgs = fn->get_args();
		    if (fnArgs.size() == 1)
		      {
			for (SgInitializedNamePtrList::iterator j = fnArgs.begin(); j != fnArgs.end(); j ++)
			  {
			    //some very janky string checking here.  Making sure arg is same as class, then checking for & in last place of type string for ref.
			    // if const is there then that's ok.
			    SgInitializedName* argVar = isSgInitializedName (*j);
			    if (!argVar) return;
			    SgType *t = argVar->get_type();
			    std::string typeName = t->unparseToString();			    
			    //this is the questionable part, experimentally true
			    std::string reference = "class ::" + className;
			  
			    SgReferenceType* sgRef = isSgReferenceType(t);
			    
			    if (sgRef)
			      {
				is_ref = true;
			      }
			    
			    if (typeName.rfind("const",0) != std::string::npos)
			      {
				is_const = true;
			      }

			    if ((is_const && typeName.substr(6,reference.length()) == reference) or (typeName.substr(0,reference.length()) == reference))
			      {
				is_copy = true;
			      }
			    
			    if (is_copy and (!is_const or !is_ref))
			      {
				//Sg_File_Info* start = cs->get_startOfConstruct();
				output->addOutput(new CheckerOutput(node));
			      }
			  }
		      }
		  }
		
	      }
	  }
	
	
     
   } //End of the visit function.
   
