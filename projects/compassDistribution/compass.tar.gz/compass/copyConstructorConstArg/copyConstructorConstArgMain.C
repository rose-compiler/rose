//
// Do not modify this file
//

#include "copyConstructorConstArg.h"
typedef CompassAnalyses::CopyConstructorConstArg::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
