//
// Do not modify this file
//

#include "charStarForString.h"
typedef CompassAnalyses::CharStarForString::Traversal Checker;

#include "compass.C"
#include "compassTestMain.C"
