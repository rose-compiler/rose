#ifndef SPAWNFRONTEND_H
#define SPAWNFRONTEND_H

#include <rose.h>

SgProject* spawnFrontend(int argc, char *argv[]);

#endif // SPAWNFRONTEND_H
