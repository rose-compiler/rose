#include "rose.h"

int main(int argc, char *argv[]) {
  SgProject* sageProject = frontend(argc,argv);
  AstTests::runAllTests(sageProject);
  AST_FILE_IO::startUp(sageProject) ;
  AST_FILE_IO::writeASTToFile("/dev/stdout");
  return 0;
}
