 
/* JH (01/03/2006): This is the class for managing the memory for the EasyStorage classes. 
   The memory is organized in blocks of length blockSize. The basic idea is 
   to store the data in a static memory pool and write this pool to disk. 
   Threrefore, every memory object contains the position and the size of its 
   data in resspect of the static memory pool. 
*/

#ifndef STORAGE_CLASS_MEMORY_MANAGEMENT_H
#define STORAGE_CLASS_MEMORY_MANAGEMENT_H

#define INITIAL_SIZE_OF_MEMORY_BLOCKS 10000
#define MEMORY_BLOCK_LIST_INCREASE 10
#define STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK 1
#define FILE_IO_MARKER 1


template <class TYPE>
class StorageClassMemoryManagement
   {
    protected:
     // Position of the start of data in the static arrays
     unsigned long positionInStaticMemoryPool;
     // amount of data stored 
     long sizeOfData;
     // total amount of data already filled in the static arrays
     static unsigned long filledUpTo;
     /* size of the memory blocks. Remarks:
        * is acutally set to INITIAL_SIZE_OF_MEMORY_BLOCKS and can be changed above  
        * is not a constant, since we set it to a new value before we rebuild the 
          data stored. Variable is changed by methods
          * arrangeMemoryPoolInOneBlock()
          * readFromFile (...)
         
     */
     static unsigned long blockSize;
     // the current working pool is located in actualBlock-1 ! 
     static unsigned int actualBlock;
     // number of memory blocks allocated 
     static unsigned int blocksAllocated;
     // the memory pool
     static TYPE **memoryBlockList;
     // pointer to the position that will be filled up next
     static TYPE *actual;

// protected  methods, only used by the derived classes! More commets can be found in 
// StorageClassMemoryManagement.C file 

  // method for initializing the working data before adding 
     long setPositionAndSizeAndReturnOffset (long sizeOfData_);

  // method that returns the a pointer beginning the beginning of the actual memory block
     TYPE* getBeginningOfActualBlock() ;

  // method that returns the a pointer beginning the beginning of the data block where
  // the data was stored! Only used while rebuilding the data, enables several asserts 
  // and eases the implementation!
     TYPE* getBeginningOfDataBlock() ;

  // "new-method": this method returns a new memory block. 
     TYPE* getNewMemoryBlock();

   public:
     StorageClassMemoryManagement () { positionInStaticMemoryPool = 0; sizeOfData = 0;  } 

  // "delete-method": delete the static memory pool. 
     static void deleteMemoryPool();

  // This method reorganizes the memory pool to contain all data in one memory block. 
      static void arrangeMemoryPoolInOneBlock();

  // return the amount of the data stored or to be stored
     long getSizeOfData() const;

  // print data that is stored, only used for debugging
     void print () const;
  
  // method for writing the memoryBlockList to disk. 
     static void writeToFile(std::ofstream& out);
 
  // reading the data from a file 
      static void readFromFile (std::ifstream& in); 
   };

/**************************************************************************************** 
   JH (01/11/2006) EasyStorage classes. These classes represent and declare the storage
   for the non-plain data in IRNodeStroge classes (located in StorageClasses.h/C).
   Remarks:
   * all class specialtizations have at least two methods
     * storeDataInEasyStorageClass 
     * rebuildDataStoredInEasyStorageClass
     to set and rebuild the data. However, they have the same name, they might have 
     slightly varying interface! 
   * in addition every class has the methods 
     * deleteMemoryPool
     * arrangeMemoryPoolInOneBlock
     and if not found in class body, it is inferited from StorageClassMemoryManagement.
   * there are some furter comments concerning the implemenation and working strategy 
     located in StorageClassMemoryManagement.C
   * the print function was only for debugging and is not located in every class it has 
     to be when called!
****************************************************************************************/

// Prototype for the EasyStorage classes, with no instatntiation! 
template <class TYPE>
class EasyStorage;

template <class TYPE>
class EasyStorageList;


// EasyStorage for arrays of chars  
template<>
class EasyStorage<char*>
   : public StorageClassMemoryManagement<char>
   {
     typedef StorageClassMemoryManagement<char> Base;
    public:
     EasyStorage() {}
     void storeDataInEasyStorageClass(const char* data_);
     void storeDataInEasyStorageClass(const char* data_, int sizeOfData_);
     char* rebuildDataStoredInEasyStorageClass();
   };

// EasyStorage for the std::string class  
template <> 
class EasyStorage<std::string>  
   : public StorageClassMemoryManagement<char>
   {
     typedef StorageClassMemoryManagement<char> Base;
    public:
     EasyStorage() {}
     void storeDataInEasyStorageClass(const std::string& data_); 
     std::string rebuildDataStoredInEasyStorageClass();
   };

// EasyStorage concerning STL vectors and lists of plain data, not sets ! 
template <class BASIC_TYPE, template <class A> class CONTAINER >
class EasyStorage <CONTAINER<BASIC_TYPE> > 
   : public StorageClassMemoryManagement<BASIC_TYPE>
   {
     typedef StorageClassMemoryManagement<BASIC_TYPE> Base;
    public:
     EasyStorage() {}
     void storeDataInEasyStorageClass(const CONTAINER<BASIC_TYPE>& data_) ;
     CONTAINER<BASIC_TYPE> rebuildDataStoredInEasyStorageClass();
   };


// EasyStorage concerning STL vectors and lists of plain data, not sets ! 
template <class BASIC_TYPE>
class EasyStorage <std::list<BASIC_TYPE> > 
   : public StorageClassMemoryManagement<BASIC_TYPE>
   {
     typedef StorageClassMemoryManagement<BASIC_TYPE> Base;
    public:
     EasyStorage() {}
     void storeDataInEasyStorageClass(const std::list<BASIC_TYPE>& data_) ;
     std::list<BASIC_TYPE> rebuildDataStoredInEasyStorageClass();
   };


// EasyStorage concerning STL vectors and lists of plain data, not sets ! 
template <class BASIC_TYPE>
class EasyStorage <std::vector<BASIC_TYPE> > 
   : public StorageClassMemoryManagement<BASIC_TYPE>
   {
     typedef StorageClassMemoryManagement<BASIC_TYPE> Base;
    public:
     EasyStorage() {}
     void storeDataInEasyStorageClass(const std::vector<BASIC_TYPE>& data_) ;
     std::vector<BASIC_TYPE> rebuildDataStoredInEasyStorageClass();
   };

// EasyStorage concerning STL sets, separate imlementation, due to insert insead of push_back ! 
template <class BASIC_TYPE >
class EasyStorage <std::set<BASIC_TYPE> > 
   : public StorageClassMemoryManagement<BASIC_TYPE>
   {
     typedef StorageClassMemoryManagement<BASIC_TYPE> Base;
    public:
     EasyStorage() {}
     void storeDataInEasyStorageClass(const std::set<BASIC_TYPE>& data_);
     std::set<BASIC_TYPE> rebuildDataStoredInEasyStorageClass();
   };

// EasyStorage concerning STL sets, separate imlementation, due to insert insead of push_back ! 
template < >
class EasyStorage <SgBitVector> 
   : public StorageClassMemoryManagement<bool>
   {
     typedef StorageClassMemoryManagement<bool> Base;
    public:
     EasyStorage() {}
     void storeDataInEasyStorageClass(const SgBitVector& data_);
     SgBitVector rebuildDataStoredInEasyStorageClass();
   };

// EasyStorage for storing a list or vector of std::strings 
template <template <class A> class CONTAINER >
class EasyStorage <CONTAINER<std::string> > 
   : public StorageClassMemoryManagement<EasyStorage<std::string> >
   {
     typedef StorageClassMemoryManagement<EasyStorage<std::string> > Base;
    public:
     EasyStorage() {}
     void storeDataInEasyStorageClass(const CONTAINER<std::string>& data_);
     void print() ;
     CONTAINER<std::string> rebuildDataStoredInEasyStorageClass() ;
     static void arrangeMemoryPoolInOneBlock() ;
     static void deleteMemoryPool() ;

     static void writeToFile(std::ofstream& out);
     static void readFromFile (std::ifstream& in);

   };

// EasyStorage for storing a list or vector of std::strings 
template <>
class EasyStorage <std::list<std::string> > 
   : public StorageClassMemoryManagement<EasyStorage<std::string> >
   {
     typedef StorageClassMemoryManagement<EasyStorage<std::string> > Base;
    public:
     EasyStorage() {}
     void storeDataInEasyStorageClass(const std::list<std::string>& data_);
     void print() ;
     std::list<std::string> rebuildDataStoredInEasyStorageClass() ;
     static void arrangeMemoryPoolInOneBlock() ;
     static void deleteMemoryPool() ;

     static void writeToFile(std::ofstream& out);
     static void readFromFile (std::ifstream& in);

   };

// EasyStorage for storing only the string contained in an SgName 
// * it has overloaded methods for arrangeMemoryPoolInOneBlock and deleteMemoryPool
template < >
class EasyStorage <SgName> 
   {
    private:
     EasyStorage <std::string> name_data; 
    public: 
     EasyStorage() {}
  // Attention: has no still default constructor ...
     void storeDataInEasyStorageClass(const SgName& name);
     SgName rebuildDataStoredInEasyStorageClass();
     static void arrangeMemoryPoolInOneBlock() ;
     static void deleteMemoryPool() ;

     static void writeToFile(std::ofstream& out);
     static void readFromFile (std::ifstream& in);
   };


// Prototype class for storing std::map entires, alias a pair!
template <class A, class B>
class EasyStorageMapEntry;
 
// EasyStorageMapEntry concerning an SgName and a Type T
// * the type T is a pain data type or a pointer address !
// * it has overloaded methods for arrangeMemoryPoolInOneBlock and deleteMemoryPool
template <class T>
class EasyStorageMapEntry <SgName,T> 
   {
    private:
     EasyStorage <SgName> sgNameString; 
     T globalIndex; 
    public: 
     EasyStorageMapEntry() {}
  // Attention: has no still default constructor ...
     void storeDataInEasyStorageClass(std::pair<const SgName, T>& iter);
     std::pair<const SgName,T>  rebuildDataStoredInEasyStorageClass();
     static void arrangeMemoryPoolInOneBlock() ;
     static void deleteMemoryPool() ;

     static void writeToFile(std::ofstream& out);
     static void readFromFile (std::ifstream& in);
   };


// EasyStorage for storing the rose_hash_multimap  
// * it has overloaded methods for arrangeMemoryPoolInOneBlock and deleteMemoryPool
template < >
class EasyStorage <rose_hash_multimap*> : 
    public StorageClassMemoryManagement <EasyStorageMapEntry<SgName,SgSymbol*> > 
   {
     typedef StorageClassMemoryManagement <EasyStorageMapEntry<SgName,SgSymbol*> > Base;
    private:
     unsigned long parent;
    public: 
     EasyStorage() {parent = 0;}
     void storeDataInEasyStorageClass(rose_hash_multimap* data_);
     rose_hash_multimap* rebuildDataStoredInEasyStorageClass();
     static void arrangeMemoryPoolInOneBlock() ;
     static void deleteMemoryPool() ;

     static void writeToFile(std::ofstream& out);
     static void readFromFile (std::ifstream& in);
   };
 
/* EasyStorageMapEntry concerning an std::string and an AstAttribut
  Remarks: 
*/
template <>
class EasyStorageMapEntry <std::string,AstAttribute*> 
   {
    private:
     EasyStorage <std::string> mapString; 
     EasyStorage <char*> attributeData; 
     EasyStorage <std::string> attributeName; 
    public: 
     EasyStorageMapEntry () {} 
     void storeDataInEasyStorageClass (const std::string& name, AstAttribute* attr);
     std::pair<std::string, AstAttribute*>  rebuildDataStoredInEasyStorageClass();
     static void arrangeMemoryPoolInOneBlock() ;
     static void deleteMemoryPool() ;

     static void writeToFile(std::ofstream& out);
     static void readFromFile (std::ifstream& in);
   };


// EasyStorage for storing the AstAttributeMechanism
// * it has overloaded methods for arrangeMemoryPoolInOneBlock and deleteMemoryPool
template < >
class EasyStorage <AstAttributeMechanism*> : 
    public StorageClassMemoryManagement < EasyStorageMapEntry<std::string,AstAttribute*> > 
   {
     typedef StorageClassMemoryManagement < EasyStorageMapEntry<std::string,AstAttribute*> > Base;
    public: 
     void storeDataInEasyStorageClass(AstAttributeMechanism* data_);
  // is only used while using the old ROSE ....
  // void rebuildDataStoredInEasyStorageClass(AstAttributeMechanism& attr) ; 
     AstAttributeMechanism* rebuildDataStoredInEasyStorageClass( ) ;
     static void arrangeMemoryPoolInOneBlock() ;
     static void deleteMemoryPool() ;

     static void writeToFile(std::ofstream& out);
     static void readFromFile (std::ifstream& in);
   };

// EasyStorage for storing the PreprocessingInfo
template <>
class EasyStorage<PreprocessingInfo*>  : 
      public StorageClassMemoryManagement <char>
   {
     typedef StorageClassMemoryManagement <char> Base;
    public: 
     void storeDataInEasyStorageClass(PreprocessingInfo* info);
     PreprocessingInfo* rebuildDataStoredInEasyStorageClass();
     static void arrangeMemoryPoolInOneBlock() ;
     static void deleteMemoryPool() ;

     static void writeToFile(std::ofstream& out);
     static void readFromFile (std::ifstream& in);
   };


// EasyStorage for storing a list or vector of std::strings 
template <template <class A> class CONTAINER >
class EasyStorage <CONTAINER<PreprocessingInfo*> > 
   : public StorageClassMemoryManagement<EasyStorage<PreprocessingInfo*> >
   {
     typedef StorageClassMemoryManagement<EasyStorage<PreprocessingInfo*> > Base;
    public:
     EasyStorage() {}
     void storeDataInEasyStorageClass(const CONTAINER<PreprocessingInfo*>& data_);
     void print() ;
     CONTAINER<PreprocessingInfo*> rebuildDataStoredInEasyStorageClass() ;
     static void arrangeMemoryPoolInOneBlock() ;
     static void deleteMemoryPool() ;

     static void writeToFile(std::ofstream& out);
     static void readFromFile (std::ifstream& in);

   };


// EasyStorage for storing a list or vector of std::strings 
template <>
class EasyStorage <std::vector<PreprocessingInfo*> > 
   : public StorageClassMemoryManagement<EasyStorage<PreprocessingInfo*> >
   {
     typedef StorageClassMemoryManagement<EasyStorage<PreprocessingInfo*> > Base;
    public:
     EasyStorage() {}
     void storeDataInEasyStorageClass(const std::vector<PreprocessingInfo*>& data_);
     void print() ;
     std::vector<PreprocessingInfo*> rebuildDataStoredInEasyStorageClass() ;
     static void arrangeMemoryPoolInOneBlock() ;
     static void deleteMemoryPool() ;

     static void writeToFile(std::ofstream& out);
     static void readFromFile (std::ifstream& in);

   };


// EasyStorage for storing a list or vector of std::strings 
template <>
class EasyStorage <AttachedPreprocessingInfoType> 
   : public StorageClassMemoryManagement<EasyStorage<PreprocessingInfo*> >
   {
     typedef StorageClassMemoryManagement<EasyStorage<PreprocessingInfo*> > Base;
    public:
     EasyStorage() {}
     void storeDataInEasyStorageClass(const AttachedPreprocessingInfoType& data_);
     void print() ;
     AttachedPreprocessingInfoType rebuildDataStoredInEasyStorageClass() ;
     static void arrangeMemoryPoolInOneBlock() ;
     static void deleteMemoryPool() ;

     static void writeToFile(std::ofstream& out);
     static void readFromFile (std::ifstream& in);

   };

// EasyStorage for storing the ROSEAttributesList (just a vector of PreprocessingInfo*)
// * it is not inherited, has its own arrangeMemoryPoolInOneBlock and deleteMemoryPool
template <>
class EasyStorage<ROSEAttributesList> 
   {
    private:
     EasyStorage < vector<PreprocessingInfo*> > preprocessingInfoVector; 
     EasyStorage < std::string > fileNameString;
     int index;
    public: 
     void storeDataInEasyStorageClass ( ROSEAttributesList* info);
     ROSEAttributesList* rebuildDataStoredInEasyStorageClass();
     static void arrangeMemoryPoolInOneBlock();
     static void deleteMemoryPool() ;

     static void writeToFile(std::ofstream& out);
     static void readFromFile (std::ifstream& in);
   };

// EasyStorage for ROSEAttributesListContainerPtr (PreprocessingInfo*)
// * it has overloaded methods for arrangeMemoryPoolInOneBlock and deleteMemoryPool
template <>
class EasyStorage <ROSEAttributesListContainerPtr> 
   : public StorageClassMemoryManagement< EasyStorage<ROSEAttributesList> >
   {
     typedef StorageClassMemoryManagement< EasyStorage<ROSEAttributesList> > Base;
    public:
     void storeDataInEasyStorageClass(const vector<ROSEAttributesList*>& data_) ;
     vector<ROSEAttributesList*> rebuildDataStoredInEasyStorageClass() ;
     static void arrangeMemoryPoolInOneBlock() ;
     static void deleteMemoryPool() ;

     static void writeToFile(std::ofstream& out);
     static void readFromFile (std::ifstream& in);
};

// EasyStorageMapEntry concerning an SgName and a Type T
// * it has overloaded methods for arrangeMemoryPoolInOneBlock and deleteMemoryPool
template < >
class EasyStorageMapEntry <std::string,int> 
   {
    private:
     EasyStorage <std::string> nameString; 
     int index; 
    public: 
     EasyStorageMapEntry () { index = 0 ; }
     void storeDataInEasyStorageClass(const std::pair<std::string, const int >& iter);
     std::pair<std::string, int >  rebuildDataStoredInEasyStorageClass();
     static void arrangeMemoryPoolInOneBlock() ;
     static void deleteMemoryPool() ;

     static void writeToFile(std::ofstream& out);
     static void readFromFile (std::ifstream& in);
   };


// EasyStorageMapEntry concerning an SgName and a Type T
// * it has overloaded methods for arrangeMemoryPoolInOneBlock and deleteMemoryPool
template < >
class EasyStorageMapEntry <int, std::string> 
   {
    private:
     int index; 
     EasyStorage <std::string> nameString;
    public: 
     EasyStorageMapEntry () { index = 0 ; }
     void storeDataInEasyStorageClass(const std::pair<const int, std::string>& iter);
     std::pair<int, std::string>  rebuildDataStoredInEasyStorageClass();
     static void arrangeMemoryPoolInOneBlock() ;
     static void deleteMemoryPool() ;

     static void writeToFile(std::ofstream& out);
     static void readFromFile (std::ifstream& in);
   };



// EasyStorage for ROSEAttributesListContainerPtr (PreprocessingInfo*)
// * it has overloaded methods for arrangeMemoryPoolInOneBlock and deleteMemoryPool
template <>
class EasyStorage < std::map<int,std::string> > 
   : public StorageClassMemoryManagement< EasyStorageMapEntry<int, std::string> >
   {
     typedef StorageClassMemoryManagement< EasyStorageMapEntry<int, std::string> > Base;
    public:
     void storeDataInEasyStorageClass(const std::map<int,std::string>& data_);
     std::map<int,std::string> rebuildDataStoredInEasyStorageClass();
     static void arrangeMemoryPoolInOneBlock();
     static void deleteMemoryPool();

     static void writeToFile(std::ofstream& out);
     static void readFromFile (std::ifstream& in);
   };



// EasyStorage for ROSEAttributesListContainerPtr (PreprocessingInfo*)
// * it has overloaded methods for arrangeMemoryPoolInOneBlock and deleteMemoryPool
template <>
class EasyStorage < std::map<std::string, int> > 
   : public StorageClassMemoryManagement< EasyStorageMapEntry<std::string, int> >
   {
     typedef StorageClassMemoryManagement< EasyStorageMapEntry<std::string, int> > Base;
    public:
     void storeDataInEasyStorageClass(const std::map<std::string,int>& data_);
     std::map<std::string,int> rebuildDataStoredInEasyStorageClass();
     static void arrangeMemoryPoolInOneBlock();
     static void deleteMemoryPool();

     static void writeToFile(std::ofstream& out);
     static void readFromFile (std::ifstream& in);
   };



/////////////////////////////////////////////////////////////////////////////////////////////////////////////


#if 0

class StorageConverter 
   {
     private:
       char* convertedData; 
       char* workPointer; 
       unsigned int convertedSize; 
     public: 
       StorageConverter ( unsigned int size ) : convertedSize (size + sizeof(unsigned int) )
          {
             convertedData = new char [convertedSize]; 
             workPointer = convertedData;
             memcpy ( workPointer, (char*) (&convertedSize), sizeof(unsigned int) );
             workPointer += sizeof(unsigned int);
          }
       StorageConverter ( char* data ) : convertedData ( data ) 
          {
             workPointer = convertedData;
             memcpy ( (char*) (&convertedSize), workPointer, sizeof(unsigned int) );
             workPointer += sizeof(unsigned int);
          }
 
       template <class TYPE>
       void addData ( const TYPE& t)
          {
            assert ( workPointer < (convertedData + convertedSize) );
            memcpy ( workPointer, (char*) (&t), sizeof(TYPE) );
            workPointer += sizeof(TYPE);
          }
 
       template <class TYPE>
       void addData ( const TYPE* t, int size )
          {
            if (t != NULL && size != 0 )
               {
                 assert ( workPointer < (convertedData + convertedSize) );
                 memcpy ( workPointer, (char*) (t), sizeof(TYPE) );
                 workPointer += sizeof(TYPE);
               }
          }
 
       void addData (char *t )
          {
            assert (t != NULL ) ;
            assert ( workPointer < (convertedData + convertedSize) );
            int size = 0; 
            memcpy ( (char*) (&size), (char*) (t), sizeof(unsigned int) );
            memcpy ( workPointer, (char*) (t), size );
            workPointer += size;
          }
       char* getConvertedData () const 
          {
            return convertedData; 
          }
       template <class TYPE> 
       void getData ( TYPE& t) 
          {
            if ( convertedSize == sizeof(unsigned int) )
               {
                  int temp = 0; 
                  memcpy ( (char*) (&t) , (char*)(&temp), sizeof(TYPE) );
                 
               } 
            else 
               {
                 assert ( workPointer < (convertedData + convertedSize) );
                 memcpy ( (char*) (&t) , workPointer , sizeof(TYPE) );
                 workPointer += sizeof(TYPE);
               }
          }
   };
#endif 

#endif  // STORAGE_CLASS_MEMORY_MANAGEMENT_H
