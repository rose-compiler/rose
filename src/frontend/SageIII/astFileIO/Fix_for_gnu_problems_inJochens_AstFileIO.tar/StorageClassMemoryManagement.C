/* JH (01/03/2006) : Setting the static data for the StorageClassMemoryManagemnt class
   This is only once inluded in StorageClasses.C and thereby it becomes only compiled 
   once. Hopefully!
*/

#include "AST_FILE_IO.h"

namespace AST_FILE_IO_MARKER
   {
      void writeMarker(std::string marker, std::ofstream& outputFileStream)
         {
#if FILE_IO_MARKER
           outputFileStream.write(marker.c_str(),marker.size());
#endif
         }
      void readMarker (std::string marker, std::ifstream& inputFileStream)
         {
#if FILE_IO_MARKER
           char *markerIn = new char[marker.size()+1];
           markerIn[marker.size()] = '\0';
           inputFileStream.read(markerIn,marker.size());
           assert (marker == markerIn);
           delete [] markerIn;
#endif
         } 
   };

// The static memory pool is empty at the beginning.
template <class TYPE> 
unsigned long StorageClassMemoryManagement<TYPE>::filledUpTo = 0;

// The size for one memory block is constantly set.
template <class TYPE> 
unsigned long StorageClassMemoryManagement<TYPE>::blockSize = INITIAL_SIZE_OF_MEMORY_BLOCKS;

// There working memory block is always actualBlock-1, so it is 
// 0 in the beginning
template <class TYPE> 
unsigned int StorageClassMemoryManagement<TYPE>::actualBlock = 0;

// There are no blocks allocated in the beginning.
template <class TYPE> 
unsigned int StorageClassMemoryManagement<TYPE>::blocksAllocated = 0;

// The memoryBlockList is pointing to a valid pointer at the start, 
// in order to be able to call the delete operator. This seems to be 
// useless, but skips one if-statment that would be called very often!
template <class TYPE> 
TYPE **StorageClassMemoryManagement<TYPE>::memoryBlockList = NULL;
//TYPE **StorageClassMemoryManagement<TYPE>::memoryBlockList = new TYPE *;

// Just a working pointer, pointing to the position to be set next. In 
// principle it is just pointing to the position filledUpTo
template <class TYPE> 
TYPE *StorageClassMemoryManagement<TYPE>::actual = NULL;

/* JH (01/03/2006) : Setting the member functions for the StorageClassMemoryManagemnt class
   This is only once inluded in StorageClasses.C and thereby it becomes only compiled 
   once. Hopefully!
*/


/* method for initializing the working data before adding
   * the sizeOfData is set
   * the positionInTheStaticMemoryPool is set to the next one that will be filled,
     namely filledUpTo
   * filledUpTo gets increased by the amount of the new data
   * finally, the offset is computed and returned. The offset contains that amount of data,
     that does not fit in the actual memory block, i.e.
      * it is negative or zero, if there is still enough space in the actual block
      * it is positive, if the data does not fit completely in the actual block
*/
template <class TYPE> 
long StorageClassMemoryManagement<TYPE> :: setPositionAndSizeAndReturnOffset (long sizeOfData_)
   {
     sizeOfData = sizeOfData_;
     positionInStaticMemoryPool = filledUpTo;
     filledUpTo += sizeOfData;
     return ( filledUpTo - actualBlock*blockSize );
  }

// method that returns the a pointer beginning the beginning of the actual memory block
template <class TYPE> 
TYPE* StorageClassMemoryManagement<TYPE> :: getBeginningOfActualBlock()
   {
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
      assert (actual != NULL);
      assert (0 < actualBlock);
      assert (memoryBlockList != NULL);
      assert (memoryBlockList[actualBlock-1] != NULL);
#endif
      return memoryBlockList[actualBlock-1];
   }



// method that returns the a pointer to the beginning of the data block stored 
// in the static array! Only used for the rebuilding of the data, in order to enable several 
// additional asserts and eases the implementation!
template <class TYPE> 
TYPE* StorageClassMemoryManagement<TYPE> :: getBeginningOfDataBlock()
   {
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
      assert (actual != NULL);
      assert (actualBlock == 1);
      assert (memoryBlockList != NULL);
      assert (memoryBlockList[0] != NULL);
      assert (0 <= sizeOfData);
      assert (filledUpTo <= blockSize) ;
#endif
      return (memoryBlockList[0] + positionInStaticMemoryPool);
   }


/* "new-method": this method returns a new memory block. First, we check, if there is still
   a free pointer in the memoryBlockList.
   * if no, we extend the memory block list by MEMORY_BLOCK_LIST_INCREASE (defined at the beginning of
     this file). Therefore, we build a new list that has space for MEMORY_BLOCK_LIST_INCREASE more memory
     block pointers. Subsequently, we copy the pointers from the old memoryBlockList to the new one,
     delete the old one, and finally replace the old one by the new one. Then we have free pointers in
     the memoryBlockList
   * if yes, we just allocate a new memory block of size blockSize, increase the actualBlock and return
     the new memory block
*/
template <class TYPE> 
TYPE* StorageClassMemoryManagement<TYPE> :: getNewMemoryBlock()
   {
     // check, wheather there is no more free block pointer
     if ( actualBlock >= blocksAllocated )
        {
        // allocate  new space for block poitners and copy the old one
        // in the new array; delete the old array
          TYPE** new_memoryBlockList = new TYPE*[blocksAllocated + MEMORY_BLOCK_LIST_INCREASE];
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
          assert (new_memoryBlockList != NULL);
#endif
          if ( memoryBlockList != NULL )
             {
                memcpy( new_memoryBlockList, memoryBlockList, blocksAllocated * sizeof(TYPE*) );
                delete [] memoryBlockList;
             }
          blocksAllocated += MEMORY_BLOCK_LIST_INCREASE;
          memoryBlockList = new_memoryBlockList;
        }
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
     assert (memoryBlockList != NULL);
#endif
  // return a new memory block and increase the actualBlock
     memoryBlockList[actualBlock] = new TYPE[blockSize];
     actualBlock++;
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
     assert (memoryBlockList[actualBlock-1] != NULL);
#endif
     return memoryBlockList[actualBlock-1];
   }


/* "delete-method": since we handle all data as static, we provide this method, in order to
   delete tehe static memory pool. If the memoryBlockList is not empty (e.g. 0 < actualBlock )
   we delete the pool, otherwise we do nothing.
*/
template <class TYPE> 
void StorageClassMemoryManagement<TYPE> :: deleteMemoryPool()
   {
     if ( 0 < actualBlock )
        {
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
          assert (memoryBlockList != NULL);
#endif
        // delete the memory pool and reset the static memoryBlockList
        // used as destructor and way to write the data only once.
          for (unsigned int i = 0; i < actualBlock; ++i)
             {
              delete [] memoryBlockList[i];
             }
          delete [] memoryBlockList;
          memoryBlockList = NULL;
          actual = NULL;
          filledUpTo = 0;
          actualBlock = 0;
          blocksAllocated = 0;
          blockSize = INITIAL_SIZE_OF_MEMORY_BLOCKS;
       }
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
  // check, if all data was reset to its initial values
     assert ( memoryBlockList == NULL ) ;
     assert ( actual == NULL ) ;
     assert ( actualBlock == 0 ) ;
     assert ( blocksAllocated == 0 ) ;
     assert ( filledUpTo == 0 ) ;
     assert ( blockSize == INITIAL_SIZE_OF_MEMORY_BLOCKS ) ;
#endif
   }

// return the amount of the data stored or to be stored
template <class TYPE> 
long StorageClassMemoryManagement<TYPE> :: getSizeOfData() const
   {
     return sizeOfData;
   }
                                                                                                                                                                                                                          
// print data that is stored, only used for debugging 
template <class TYPE> 
void StorageClassMemoryManagement<TYPE> :: print () const
   {
     for (unsigned long i = 0; i < getSizeOfData(); ++i)
        {
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
          assert (memoryBlockList != NULL);
#endif
          unsigned int offset = (positionInStaticMemoryPool+i)%blockSize;
          std::cout << memoryBlockList[(positionInStaticMemoryPool+i-offset)/blockSize][offset];
        }
   }
                                                                                                                                                                                                                          

/* method for writing the memoryBlockList to disk. Only the amount of the data and the static
   data gets stored. The plain data (positionInStaticMemoryPool, sizeOfData) is stored by the
   class where the EasyStorage object is declared and used. Therefore, the any EasyStorage
   class might always be a object, never a poitner.
   Further, we always save the filledUpTo, even if the data is already stored and filledUpTo
   was set to 0. Then we store just the 0 and nothin more is done. The reasen for this is 
   the reading back of the data is calles in the same order and will so read the 0 and 
   also do nothing. I am not very glad with this implementation, because this 0s could be 
   spared, by changing the StorageClassMemoryManagement class. Since this is not a real 
   perofrmace issue (its only static data, and we already try to spare the doubles in
   the StorageClasses) I just leave it in that manner. But this can be improved!
*/
template <class TYPE> 
void StorageClassMemoryManagement<TYPE> :: writeToFile(std::ofstream& outputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::writeMarker("|01|",outputFileStream);
#endif
     outputFileStream.write((char*)(&filledUpTo),sizeof(filledUpTo));
      // since the method might get called several times, we only want to store once 
     if ( 0 < filledUpTo )
        {
          assert ( actual != NULL );
          assert ( memoryBlockList != NULL );
          assert ( 0 < actualBlock );
          for ( unsigned int i = 0; i < actualBlock-1; ++i )
             {
               assert ( memoryBlockList[i] != NULL );
               outputFileStream.write((char*)(memoryBlockList[i]),blockSize * sizeof(TYPE) );
             }
          outputFileStream.write((char*)(memoryBlockList[actualBlock-1]),( (filledUpTo-1)%blockSize + 1) * sizeof(TYPE) );
       // delete the pool, since the data is not needed any more!
          deleteMemoryPool();
        }
   }

                                                                                                                                                                                                                          
/* reading the data from a file. Since we read first the total amount of datai ( stored in
   filledUpTo ), the memory pool is created in the manner, that is has only one memory block
   with filledUpTo size, i.e. memoryBlockSize is set to filledUpTo. Reasons for this
   construction:
    * this accelerates the reading of the data, since we can read one big block from disk
    * the location of the data ( positionInStaticMemoryPool ) is the global position in the pool.
      Therefore, we just can access the position without any further pool computations
*/
template <class TYPE>
void StorageClassMemoryManagement<TYPE> :: readFromFile (std::ifstream& inputFileStream)
    {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::readMarker("|01|",inputFileStream);
#endif
      inputFileStream.read((char*)(&filledUpTo),sizeof(filledUpTo));
      // since the method might get called several times, we only want to read
      // the data one.
      if ( 0 < filledUpTo )
         {
           assert ( actual == NULL ) ;
           assert ( memoryBlockList == NULL );
           memoryBlockList = new TYPE*[1];
           memoryBlockList[0] = new TYPE[filledUpTo];
           inputFileStream.read((char*)(memoryBlockList[0]),filledUpTo * sizeof(TYPE) );
           blockSize = filledUpTo;
           actualBlock = 1;
           blocksAllocated = 1;
           actual = memoryBlockList[0] + filledUpTo;
        }
    }

                                                                                                                                                                                                                          
/* This method reorganizes the memory pool to contain all data in one memory block.
   It is only used for testing, for storing and repairing the data without writing
   to a file !
*/
template <class TYPE>
void StorageClassMemoryManagement<TYPE> :: arrangeMemoryPoolInOneBlock()
    {
      // check, wheather the data belongs to more than one memory block
      if ( actual != NULL )
         {
           if ( 1 < actualBlock )
              {
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
               assert (memoryBlockList != NULL);
#endif
                TYPE * newMemoryBlock = new TYPE [filledUpTo];
                unsigned int i = 0;
                for (i=0; i < actualBlock - 1; ++i)
                   {
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
                     assert (memoryBlockList[i] != NULL);
#endif
                     memcpy( newMemoryBlock + (i*blockSize) , memoryBlockList[i] , blockSize*sizeof(TYPE) );
                   }
                memcpy( newMemoryBlock + i * blockSize, memoryBlockList[i], ( (filledUpTo-1)%blockSize + 1) * sizeof(TYPE));
                for (i = 0; i < actualBlock; ++i)
                   {
                     delete [] memoryBlockList[i];
                   }
                memoryBlockList[0] = newMemoryBlock;
                blockSize = filledUpTo;
                actual = &(memoryBlockList[0][filledUpTo]);
                actualBlock = 1;
                blocksAllocated = 1;
              }
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
           assert (memoryBlockList != NULL);
           assert (memoryBlockList[0] != NULL);
           assert ( filledUpTo <= blockSize);
           assert ( actual != NULL );
           assert ( actualBlock <= 1 );
#endif
         }
    }

/***************************************************************************************
  JH (01/11/2006) EasyStorage for arrays of plain data (mainly char arrays)
  Some comments to the implementation at all:
  * NULL pointers are stored equally to empty arrays, lists, etc. This means, that if 
    rebuilded we will have an valid object behind the pointer. The exeptions are 
    * AstAttributeMechanism
    therefore an NULL pointer will be recreated ( this is realized by setting sizeOfData
    to -1 and check while rebuilt)
  * the actual pointer is pointing to the next position to bestored in. Except for the case, the
    memmory pool is not allocated at all, then the actual pointer is NULL. Therefore, we use
    the actual pointer for checking if the pool is valid (everytime you see (actual != NULL) )
  * every storting is mainly separated in 2 parts: 
    * the setup with the call of setPositionAndSizeAndReturnOffset
    * the storing of the data, checking, wheather it fits in the achtual memory block or not 
      ( done by ( 0 < offset ) )
      * the case it does not fit is separated in 2 or 3 parts
        * filling the actual memory block 
        * getting a new block and iterating while the rest of the data does not fit in a 
          whole memory block
        * storing of the rest ( runs sometimes just to storing data ) 
    * more complex data (PreprocessingInfo, maps, AstAttributeMechanism) contain 
      EasyStorage classes themself. Therefore, we must provide explicit member fumctions
      deleting the static data of those. These functions call also the corresponing one 
      of the parent class (if the class is an inheritated class). 
***************************************************************************************/

/*
   ****************************************************************************************
   **           Implementations for EasyStorage <char*>                                  **
   ****************************************************************************************
*/
void EasyStorage<char*> :: storeDataInEasyStorageClass(const char* data_)
   {
     if ( data_ == NULL )
        { 
          sizeOfData = -1;
        }
     else 
        {
          storeDataInEasyStorageClass( data_, strlen(data_) );
        }
   }
void EasyStorage<char*> :: storeDataInEasyStorageClass(const char* data_, int sizeOfData_)
   {
     typedef StorageClassMemoryManagement<char> Base;
     if ( data_ == NULL )
        { 
          sizeOfData = -1;
        }
     else
        {
       // get changeable pointer
          char* copy_ = const_cast<char*>(data_);
          long offset = Base::setPositionAndSizeAndReturnOffset ( sizeOfData_ ) ;
       // if the new data does not fit in the actual block
          if (0 < offset) 
             {
            // if there is still space in the actual block
               if ( offset < Base::getSizeOfData() && Base::actual != NULL ) 
                  {
                    memcpy( Base::actual, copy_, (Base::getSizeOfData()-offset)*sizeof(char) );
                    copy_ += (Base::getSizeOfData()-offset);
                  }
           // the data does not fit in one block
               while (Base::blockSize < (unsigned long)(offset))
                  {
                    Base::actual = Base::getNewMemoryBlock();
                    memcpy(Base::actual, copy_, Base::blockSize*sizeof(char) );
                    offset -= Base::blockSize;
                    copy_ += Base::blockSize;
                  };
            // put the rest of the data in a new memory block
               Base::actual = Base::getNewMemoryBlock();
               memcpy(Base::actual, copy_, offset*sizeof(char) );
               Base::actual += offset;
             }
          else
             {
            // put the the data in the memory block
               memcpy(Base::actual, copy_, Base::getSizeOfData()*sizeof(char) );
               Base::actual += Base::getSizeOfData();
             }
        }
  }


char* EasyStorage<char*> :: rebuildDataStoredInEasyStorageClass()
   {
     typedef StorageClassMemoryManagement<char> Base;
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
      assert ( actualBlock <= 1 );
      assert ( (0 < getSizeOfData() && actual!= NULL) || ( getSizeOfData() <= 0 ) );
#endif
   
      char* data_ = NULL ;
      if ( 0 <= Base::getSizeOfData() )
         {
           data_ = new char[Base::getSizeOfData()+1];
        // if there is any data in the pool at all
           if ( Base::actual != NULL  && 0 < Base::getSizeOfData() )
              {
                char* dataPointer = Base::getBeginningOfDataBlock();
                memcpy(data_, dataPointer, Base::getSizeOfData() * sizeof(char) );
              }
        // terminate char array
           data_[Base::getSizeOfData()] = '\0';
         }
      return data_;
   }


/*
   ****************************************************************************************
   **           Implementations for EasyStorage <std::string >                           **
   ****************************************************************************************
*/
void EasyStorage<std::string> :: storeDataInEasyStorageClass(const std::string& data_)
   {
     typedef StorageClassMemoryManagement<char> Base;
  // get changeable pointer
     char* copy_ = const_cast<char*>(data_.c_str());
     long offset = Base::setPositionAndSizeAndReturnOffset ( strlen(copy_) ) ;
  // if the new data does not fit in the actual block
     if (0 < offset)
        { 
       // if there is still space in the actual block
          if ( offset < Base::getSizeOfData() && Base::actual != NULL )
             { 
               memcpy(Base::actual, copy_, (Base::getSizeOfData()-offset)*sizeof(char) );
               copy_ += (Base::getSizeOfData()-offset);
             }
      // the data does not fit in one block
          while (Base::blockSize < (unsigned long)(offset))
             {
               Base::actual = Base::getNewMemoryBlock();
               memcpy(Base::actual, copy_, Base::blockSize*sizeof(char) );
               offset -= Base::blockSize;
               copy_ += Base::blockSize;
             };
       // put the rest of the data in a new memory block
          Base::actual = Base::getNewMemoryBlock();
          memcpy(Base::actual, copy_ , offset*sizeof(char) );
          Base::actual += offset;
        }
     else
        {
       // put the the data in the memory block
          memcpy(Base::actual, copy_, Base::getSizeOfData()*sizeof(char) );
          Base::actual += Base::getSizeOfData();
        }
   }
                                                                                                                                                                                                                          

std::string EasyStorage<std::string> :: rebuildDataStoredInEasyStorageClass()
   {
     typedef StorageClassMemoryManagement<char> Base;
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
      assert ( Base::actualBlock <= 1 );
      assert ( (0 < Base::getSizeOfData() && Base::actual!= NULL) || ( Base::getSizeOfData() == 0 ) );
#endif
      std::string return_string;
   // if there is any data in the pool at all
      if (Base::actual != NULL && 0 < Base::getSizeOfData() )
         {
           char* dataPointer = Base::getBeginningOfDataBlock();
           return_string = std::string(dataPointer,getSizeOfData());
         }
      return return_string;
   }


/*
   ****************************************************************************************
   **       Implementations for EasyStorage <CONTAINER<TYPE> >                           **
   ****************************************************************************************
*/
template <class TYPE, template <class A> class CONTAINER >
void EasyStorage <CONTAINER<TYPE> > :: storeDataInEasyStorageClass(const CONTAINER<TYPE>& data_)
   {
  // get iterator pointing to begin
     typedef StorageClassMemoryManagement<TYPE> Base;
     typename CONTAINER<TYPE>::const_iterator dat = data_.begin();
     long offset = Base::setPositionAndSizeAndReturnOffset ( data_.size() ) ;
  // if the new data does not fit in the actual block
     if (0 < offset)
        {
       // if there is still space in the actual block
          if ( offset < Base::getSizeOfData() && Base::actual != NULL )
             {
               for (; (unsigned long)(Base::actual - Base::getBeginningOfActualBlock()) < Base::blockSize; 
                      ++Base::actual, ++dat)
                  {
                    *Base::actual = *dat;
                  }
             }
       // the data does not fit in one block
          while (Base::blockSize < (unsigned long)(offset))
             {
               Base::actual = Base::getNewMemoryBlock();
               for (; (unsigned long)(Base::actual - Base::getBeginningOfActualBlock()) < Base::blockSize; ++Base::actual, ++dat)
                  {
                    *Base::actual = *dat;
                  }
               offset -= Base::blockSize;
             };
       // get a new memory block 
          Base::actual = Base::getNewMemoryBlock();
        }
  // put (the rest of) the data in a new memory block
     for (; dat != data_.end(); ++dat, ++Base::actual)
        {
		  *Base::actual = *dat;
        }
   }
                                                                                                                                                                                                                          
template <class TYPE, template <class A> class CONTAINER >
CONTAINER<TYPE> EasyStorage <CONTAINER<TYPE> > :: rebuildDataStoredInEasyStorageClass()
   {
     typedef StorageClassMemoryManagement<TYPE> Base;
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
     assert ( Base::actualBlock <= 1 );
     assert ( (0 < Base::getSizeOfData() && Base::actual!= NULL) || ( Base::getSizeOfData() == 0 ) );
#endif
     
     CONTAINER<TYPE> data_;
   // if there is data in the memory pool at all
      if ( Base::actual != NULL  && 0 < Base::getSizeOfData() )
         {
           TYPE* pointer = Base::getBeginningOfDataBlock();
           for (long i=0; i < Base::getSizeOfData(); ++i )
              {
                data_.push_back(*(pointer+i));
              }
         }
      return data_;
   }


/*
   ****************************************************************************************
   **       Implementations for EasyStorage <std::set<TYPE> >                            **
   ****************************************************************************************
*/
template <class TYPE >
void EasyStorage <std::set<TYPE> > :: storeDataInEasyStorageClass(const std::set<TYPE>& data_)
   {
     typedef StorageClassMemoryManagement<TYPE> Base;
  // get iterator pointing to begin
     typename std::set<TYPE>::const_iterator dat = data_.begin();
     long offset = Base::setPositionAndSizeAndReturnOffset ( data_.size() ) ;
  // if the new data does not fit in the actual block
     if (0 < offset)
        {
       // if there is still space in the actual block
          if ( offset < Base::getSizeOfData() && Base::actual != NULL )
             {
               for (; (unsigned long)(Base::actual - Base::getBeginningOfActualBlock()) < Base::blockSize; ++Base::actual, ++dat)
                  {
                    *Base::actual = *dat;
                  }
             }
       // the data does not fit in one block
          while (Base::blockSize < (unsigned long)(offset))
             {
               Base::actual = Base::getNewMemoryBlock();
               for (; (unsigned long)(Base::actual - Base::getBeginningOfActualBlock()) < Base::blockSize; ++Base::actual, ++dat)
                  {
                    *Base::actual = *dat;
                  }
               offset -= Base::blockSize;
             };
       // get a new memory block
          Base::actual = Base::getNewMemoryBlock();
        }
  // put (the rest of) the data in a new memory block
     for (; dat != data_.end(); ++dat, ++Base::actual)
        {
          *Base::actual = *dat;
        }
   }
                                                                                                                                                                                                                          
template <class TYPE >
std::set<TYPE> EasyStorage <std::set<TYPE> > :: rebuildDataStoredInEasyStorageClass()
   {
     typedef StorageClassMemoryManagement<TYPE> Base;
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
      assert ( Base::actualBlock <= 1 );
      assert ( (0 < Base::getSizeOfData() && Base::actual!= NULL) || ( Base::getSizeOfData() == 0 ) );
#endif
      std::set<TYPE> data_;
   // if there is data in the memory pool at all
      if ( Base::actual != NULL  && 0 < Base::getSizeOfData() )
         {
           TYPE* pointer = Base::getBeginningOfDataBlock();
           for (long  i=0; i < Base::getSizeOfData(); ++i )
              {
                data_.insert(*(pointer+i));
              }
         }
      return data_;
   }


/*
   ****************************************************************************************
   **       Implementations for EasyStorage <std::list<std::string> >                    **
   ****************************************************************************************
*/
void EasyStorage <std::list<std::string> > :: storeDataInEasyStorageClass(const std::list<std::string>& data_)
   {
     typedef StorageClassMemoryManagement<EasyStorage<std::string> > Base;
  // get iterator pointing to begin
     std::list<std::string>::const_iterator copy_ = data_.begin();
     long offset = Base::setPositionAndSizeAndReturnOffset ( data_.size() ) ;
  // if the new data does not fit in the actual block
     if (0 < offset)
        { 
       // if there is still space in the actual block
          if ( offset < Base::getSizeOfData() && Base::actual != NULL )
             { 
               for (; (unsigned long)(Base::actual - Base::getBeginningOfActualBlock()) < Base::blockSize; ++Base::actual, ++copy_)
                  {
                    Base::actual->storeDataInEasyStorageClass(*copy_);
                  }
             }
      // the data does not fit in one block
          while (Base::blockSize < (unsigned long)(offset))
             {
               Base::actual = Base::getNewMemoryBlock();
               for (; (unsigned long)(Base::actual - Base::getBeginningOfActualBlock()) < Base::blockSize; ++Base::actual, ++copy_)
                  {
                    Base::actual->storeDataInEasyStorageClass(*copy_);
                  }
               offset -= Base::blockSize;
             };
       // get a new memory block
          Base::actual = Base::getNewMemoryBlock();
        }
  // put (the rest of) the data in a new memory block
     for ( ; copy_ != data_.end(); ++copy_, ++Base::actual )
        {
          Base::actual->storeDataInEasyStorageClass(*copy_);
        }
   }


void EasyStorage <std::list<std::string> > ::  print()
   {
     typedef StorageClassMemoryManagement<EasyStorage<std::string> > Base;
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
     assert ( Base::memoryBlockList != NULL );
#endif

     for (unsigned long i = 0; i < Base::getSizeOfData(); ++i)
        {
          long offset = (Base::positionInStaticMemoryPool+i)%Base::blockSize;
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
          assert ( Base::memoryBlockList[(Base::positionInStaticMemoryPool+i-offset)/Base::blockSize] != NULL );
#endif
          Base::memoryBlockList[(Base::positionInStaticMemoryPool+i-offset)/Base::blockSize][offset].print();
          std::cout << std::endl;
        }
   }


std::list<std::string> EasyStorage <std::list<std::string> > :: rebuildDataStoredInEasyStorageClass()
   {
     typedef StorageClassMemoryManagement<EasyStorage<std::string> > Base;
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
      assert ( Base::actualBlock <= 1 );
      assert ( (0 < Base::getSizeOfData() && Base::actual!= NULL) || ( Base::getSizeOfData() == 0 ) );
#endif
      std::list<std::string> data_;
   // if there is any data in the pool
      if ( Base::actual != NULL  && 0 < Base::getSizeOfData() )
         {
           EasyStorage<std::string> *pointer = Base::getBeginningOfDataBlock();
           for ( long i=0; i < Base::getSizeOfData(); ++i )
              {
                data_.push_back( (pointer+i)->rebuildDataStoredInEasyStorageClass() );
              }
         }
      return data_;
   }

void EasyStorage <std::list<std::string> > :: arrangeMemoryPoolInOneBlock()
   {
    // calling the base class 
     StorageClassMemoryManagement<EasyStorage<std::string> > :: arrangeMemoryPoolInOneBlock();
    // calling the basic type 
     EasyStorage <std::string> :: arrangeMemoryPoolInOneBlock(); 
   }

void EasyStorage <std::list<std::string> > :: deleteMemoryPool() 
   {
    // calling the base class 
     StorageClassMemoryManagement<EasyStorage<std::string> > :: deleteMemoryPool();
    // calling the basic type 
     EasyStorage <std::string> :: deleteMemoryPool(); 
   }


void EasyStorage <std::list<std::string> > :: writeToFile(std::ofstream& outputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::writeMarker("|02|",outputFileStream);
#endif
    // calling the base class 
     StorageClassMemoryManagement<EasyStorage<std::string> > :: writeToFile(outputFileStream);
    // calling the basic type 
     EasyStorage <std::string> :: writeToFile(outputFileStream);
   }

void EasyStorage <std::list<std::string> > :: readFromFile (std::ifstream& inputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::readMarker("|02|",inputFileStream);
#endif
    // calling the base class 
     StorageClassMemoryManagement<EasyStorage<std::string> > :: readFromFile (inputFileStream);
    // calling the basic type 
     EasyStorage <std::string> :: readFromFile (inputFileStream);
   }



/*
   ****************************************************************************************
   **                Implementations for EasyStorage <SgName>                            **
   ****************************************************************************************
*/
/* The EasyStorage <SgName> class is not derived from the StorageClassMemoryManagement class!
   This is not necessary, since it only holds a data member EasyStorage <std::string>, which 
   really contains the data ! Thus, the static data functions just have to call the methods 
   on the data member type EasyStorage <std::string>!!
*/
void EasyStorage <SgName> :: storeDataInEasyStorageClass(const SgName& name)
   {
    // calling the method on the data member
       name_data.storeDataInEasyStorageClass(name.getString());
   }

SgName EasyStorage <SgName> :: rebuildDataStoredInEasyStorageClass()
   {
    // calling the method on the data member
      return SgName (name_data.rebuildDataStoredInEasyStorageClass());
   }

void EasyStorage <SgName> :: arrangeMemoryPoolInOneBlock()
   {
    // calling the method on the data member
      EasyStorage <std::string> :: arrangeMemoryPoolInOneBlock();
   }


void EasyStorage <SgName> :: deleteMemoryPool()
   {
    // calling the method on the data member
     EasyStorage <std::string> :: deleteMemoryPool ();
   }


void EasyStorage <SgName> :: writeToFile(std::ofstream& outputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::writeMarker("|03|",outputFileStream);
#endif
    // calling the method on the data member
      EasyStorage <std::string> :: writeToFile(outputFileStream);
   }


void EasyStorage <SgName> :: readFromFile (std::ifstream& inputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::readMarker("|03|",inputFileStream);
#endif
    // calling the method on the data member
     EasyStorage <std::string> :: readFromFile (inputFileStream);
   }


/*
   ****************************************************************************************
   **      Implementations for EasyStorageMapEntry <SgName,T>                            **
   ****************************************************************************************
*/
/* Since the class  EasyStorageMapEntry <SgName,T> is not inherited from StorageClassMemoryManagement,
   it does not have to call the static member functions of the base class! 
*/
template <class T>
void EasyStorageMapEntry <SgName,T> :: storeDataInEasyStorageClass(std::pair<const SgName, T>& iter)
   {
    // calling the method on the data member
       sgNameString.storeDataInEasyStorageClass(iter.first);
       globalIndex = (T) (iter.second);
   }

template <class T>
std::pair<const SgName,T> EasyStorageMapEntry <SgName,T> :: rebuildDataStoredInEasyStorageClass()
   {
    // calling the method on the data member
      std::pair<const SgName,T> return_pair(sgNameString.rebuildDataStoredInEasyStorageClass(), (T)(globalIndex) );
      return return_pair;
   }

template <class T>
void EasyStorageMapEntry <SgName,T> :: arrangeMemoryPoolInOneBlock()
   {
    // calling the method on the data member
      EasyStorage <SgName> :: arrangeMemoryPoolInOneBlock();
   }

template <class T>
void EasyStorageMapEntry <SgName,T> :: deleteMemoryPool()
   {
  // calling the method on the data member
     EasyStorage <SgName> :: deleteMemoryPool();
   }


template <class T>
void EasyStorageMapEntry <SgName,T> :: writeToFile(std::ofstream& outputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::writeMarker("|04|",outputFileStream);
#endif
    // calling the method on the data member
      EasyStorage <SgName> :: writeToFile(outputFileStream);
   }

template <class T>
void EasyStorageMapEntry <SgName,T> :: readFromFile (std::ifstream& inputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::readMarker("|04|",inputFileStream);
#endif
  // calling the method on the data member
     EasyStorage <SgName> :: readFromFile (inputFileStream);
   }


/*
   ****************************************************************************************
   **      Implementations for EasyStorage <rose_hash_multimap*>                         **
   ****************************************************************************************
*/
void EasyStorage <rose_hash_multimap*> ::storeDataInEasyStorageClass(rose_hash_multimap* data_)
   {
     typedef StorageClassMemoryManagement<EasyStorageMapEntry<SgName,SgSymbol*> > Base;
     if ( data_ == NULL )
        { 
          sizeOfData = -1;
        }
     else 
        {
       // store the parent pointer as unsigned long (this should better be AddrType). FixMe, also in the class declaration ! 
          parent = AST_FILE_IO :: getGlobalIndexFromSgClassPointer( data_->parent );
       // get staring iterator
          hash_multimap<const SgName, SgSymbol*, hash_Name, eqstr>::iterator copy_ = data_->begin();
          long offset = Base::setPositionAndSizeAndReturnOffset ( data_->size() ) ;
       // if the new data does not fit in the actual block
          if (0 < offset)
             {
            // if there is still space in the actual block
               if ( offset < Base::getSizeOfData() && Base::actual != NULL )
                  {
                    for (;(unsigned long)(Base::actual - Base::getBeginningOfActualBlock())<Base::blockSize; ++Base::actual, ++copy_)
                       {
                         Base::actual->storeDataInEasyStorageClass(*copy_);
                       }
                  }
            // the data does not fit in one block
               while (Base::blockSize < (unsigned long)(offset))
                 {
                  Base::actual = Base::getNewMemoryBlock();
                  for (; (unsigned long)(Base::actual - Base::getBeginningOfActualBlock()) < Base::blockSize; ++Base::actual, ++copy_)
                     {
                      Base::actual->storeDataInEasyStorageClass(*copy_);
                     }
                  offset -= Base::blockSize;
                 };
            // get new memory block, since the old one is full
               Base::actual = Base::getNewMemoryBlock();
             }
       // store the (rest of the ) data 
          for ( ; copy_ != data_->end(); ++copy_, ++Base::actual )
             {
              Base::actual->storeDataInEasyStorageClass(*copy_);
             }
        }
   }


rose_hash_multimap* 
EasyStorage <rose_hash_multimap*> :: rebuildDataStoredInEasyStorageClass()
   {
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
      assert ( actualBlock <= 1 );
      assert ( (0 < getSizeOfData() && actual!= NULL) || ( getSizeOfData() <= 0 ) );
#endif
     rose_hash_multimap* return_map = NULL;
     if ( 0 <= getSizeOfData() )
        {
          return_map = new rose_hash_multimap();
       // set the parent
          return_map->parent = AST_FILE_IO :: getSgClassPointerFromGlobalIndex(parent);
       // if the memory pool is valid 
          if ( actual != NULL  && 0 < getSizeOfData() )
             {
               EasyStorageMapEntry<SgName,SgSymbol*> *pointer = getBeginningOfDataBlock();
               for (int i = 0; i < getSizeOfData(); ++i)
                  {
                    return_map->insert((pointer+i)->rebuildDataStoredInEasyStorageClass()) ;
                  }
             }
        }
     return return_map;
   }


void EasyStorage <rose_hash_multimap*> :: arrangeMemoryPoolInOneBlock()
   {
   // call suitable methods of parent and member
      StorageClassMemoryManagement <EasyStorageMapEntry<SgName,SgSymbol*> > :: arrangeMemoryPoolInOneBlock();
      EasyStorageMapEntry <SgName,SgSymbol*> :: arrangeMemoryPoolInOneBlock();
   }


void EasyStorage <rose_hash_multimap*> :: deleteMemoryPool()
   {
   // call suitable methods of parent and member
     StorageClassMemoryManagement <EasyStorageMapEntry<SgName,SgSymbol*> > :: deleteMemoryPool();
     EasyStorageMapEntry <SgName,SgSymbol*> :: deleteMemoryPool();
   }


void EasyStorage <rose_hash_multimap*> :: writeToFile(std::ofstream& outputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::writeMarker("|05|",outputFileStream);
#endif
   // call suitable methods of parent and member
      StorageClassMemoryManagement <EasyStorageMapEntry<SgName,SgSymbol*> > :: writeToFile(outputFileStream);
      EasyStorageMapEntry <SgName,SgSymbol*> :: writeToFile( outputFileStream);
   }


void EasyStorage <rose_hash_multimap*> :: readFromFile (std::ifstream& inputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::readMarker("|05|",inputFileStream);
#endif
   // call suitable methods of parent and member
     StorageClassMemoryManagement <EasyStorageMapEntry<SgName,SgSymbol*> > :: readFromFile (inputFileStream);
     EasyStorageMapEntry <SgName,SgSymbol*> :: readFromFile (inputFileStream);
   }




/*
   ****************************************************************************************
   **      Implementations for EasyStorageMapEntry <std::string,AstAttribute*>           **
   ****************************************************************************************
*/
// Is not inherited from StorageClassMemoryManagement!!!!
void EasyStorageMapEntry <std::string,AstAttribute*> :: storeDataInEasyStorageClass (const std::string& name, AstAttribute* attr)
   {
   // call suitable methods of parent and member
      mapString.storeDataInEasyStorageClass(name);
      attributeData.storeDataInEasyStorageClass(attr->packed_data(), attr->packed_size() );
      attributeName.storeDataInEasyStorageClass( attr->attribute_class_name() );
   }


std::pair<std::string, AstAttribute*> 
EasyStorageMapEntry <std::string,AstAttribute*> :: rebuildDataStoredInEasyStorageClass()
   {
   // call suitable methods of parent and member
      AstAttribute *ret = NULL ;
   // register of the userdefined AstAttribute must be done before reading in. It will print an  error message, that contains
   // name of the attribute and some info how to register it  
   // stored in the right manner but, before rebuilding it has to be registered!
      std :: map < std::string, AST_FILE_IO::CONSTRUCTOR > regAttr = AST_FILE_IO :: getRegisteredAttributes();
      std::string storedAttributeName = attributeName.rebuildDataStoredInEasyStorageClass();
      if ( regAttr.find ( storedAttributeName ) != regAttr.end() )
         {
            ret = (ret->*regAttr[ storedAttributeName ]) ();
            ret->unpacked_data( attributeData.getSizeOfData(), attributeData.rebuildDataStoredInEasyStorageClass() );
         }
      else
         {
            std::cerr << "Attribute " << storedAttributeName << " not found registered, building default AstAttribute instead ... " << std::endl;
            ret = (ret->*regAttr["AstAttribute"]) ();
         }
      std::pair<std::string, AstAttribute*> return_pair(mapString.rebuildDataStoredInEasyStorageClass(), ret );
      return return_pair;
   }

void EasyStorageMapEntry <std::string,AstAttribute*> :: arrangeMemoryPoolInOneBlock()
   {
  // EasyStorage <std::string> occurs twice, but is only called once!!!!!!!!
     EasyStorage <std::string>  :: arrangeMemoryPoolInOneBlock();
     EasyStorage <char*>  :: arrangeMemoryPoolInOneBlock();

   }


void EasyStorageMapEntry <std::string,AstAttribute*> :: deleteMemoryPool()
   {
  // EasyStorage <std::string> occurs twice, but is only called once!!!!!!!!
     EasyStorage <std::string>  :: deleteMemoryPool();
     EasyStorage <char*>  :: deleteMemoryPool();

   }


void EasyStorageMapEntry <std::string,AstAttribute*> :: writeToFile(std::ofstream& outputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::writeMarker("|06|",outputFileStream);
#endif
  // EasyStorage <std::string> occurs twice, but is only called once!!!!!!!!
     EasyStorage <std::string>  :: writeToFile(outputFileStream);
     EasyStorage <char*>  :: writeToFile(outputFileStream);

   }


void EasyStorageMapEntry <std::string,AstAttribute*> :: readFromFile (std::ifstream& inputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::readMarker("|06|",inputFileStream);
#endif
  // EasyStorage <std::string> occurs twice, but is only called once!!!!!!!!
     EasyStorage <std::string>  :: readFromFile (inputFileStream);
     EasyStorage <char*>  :: readFromFile (inputFileStream);

   }


/*
   ****************************************************************************************
   **      Implementations for EasyStorage <AstAttributeMechanism*>                      **
   ****************************************************************************************
*/
void EasyStorage <AstAttributeMechanism*> :: storeDataInEasyStorageClass(AstAttributeMechanism* data_)
   { 
     typedef  StorageClassMemoryManagement <EasyStorageMapEntry<std::string,AstAttribute*> > Base;
  // REMARK !!!!! Here we store a pointer that was a NULL pointer in a manner, that it 
  // can be rebuilt (sizeOfData = - 1)
     if ( data_ == NULL )
        {
          Base::sizeOfData = -1;
          Base::positionInStaticMemoryPool = 0;
        }
     else
        {
      // get starting data
          std::set<std::string> first_data = data_->getAttributeIdentifiers();
          std::set<std::string>::iterator copy_ = first_data.begin();
          long offset = Base::setPositionAndSizeAndReturnOffset ( first_data.size() ) ;
       // if the new data does not fit in the actual block
          if (0 < offset)
             { 
            // if there is still space in the actual block
               if ( offset < Base::getSizeOfData() && Base::actual != NULL )
                  {
                    for (; (unsigned long)(Base::actual - Base::getBeginningOfActualBlock()) < Base::blockSize; ++Base::actual, ++copy_)
                       {
                         Base::actual->storeDataInEasyStorageClass( *copy_ , (*data_)[*copy_]);
                       }
                  }
            // the data does not fit in one block
               while (Base::blockSize < (unsigned long)(offset))
                  {
                    Base::actual = Base::getNewMemoryBlock();
                    for (; (unsigned long)(Base::actual - Base::getBeginningOfActualBlock()) < Base::blockSize; ++Base::actual, ++copy_)
                       {
                         Base::actual->storeDataInEasyStorageClass(*copy_, (*data_)[*copy_]);
                       }
                    offset -= Base::blockSize;
                  };
            // get a new memory block (since the actual one is full)
               Base::actual = Base::getNewMemoryBlock();
             }
       // store the (rest of the) data
          for ( ; copy_ != first_data.end(); ++copy_, ++Base::actual )
             {
               Base::actual->storeDataInEasyStorageClass(*copy_, (*data_)[*copy_]);
             }
        }
   }


AstAttributeMechanism* EasyStorage <AstAttributeMechanism*> :: rebuildDataStoredInEasyStorageClass()
   {
     typedef  StorageClassMemoryManagement <EasyStorageMapEntry<std::string,AstAttribute*> > Base;
     AstAttributeMechanism* return_attribute = NULL;
    // check wheather data was not a NULL pointer ...
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
      assert ( Base::actualBlock <= 1 );
      assert ( (0 < Base::getSizeOfData() && Base::actual!= NULL) || ( Base::getSizeOfData() <= 0 ) );
#endif
       if ( Base::getSizeOfData()  != -1 )
          {
         // if the memory pool is valid
            assert ( Base::actualBlock <= 1 );
            if ( Base::actual != NULL  && 0 < Base::getSizeOfData() )
               {
                 assert ( Base::actualBlock == 1 );
                 return_attribute = new AstAttributeMechanism;
                 EasyStorageMapEntry<std::string,AstAttribute*> *pointer = Base::getBeginningOfDataBlock();
                 std::pair<std::string, AstAttribute*> entry;

                 for (int i = 0; i < Base::getSizeOfData(); ++i)
                    {
                      entry = (pointer+i)->rebuildDataStoredInEasyStorageClass();
                      return_attribute->add(entry.first, entry.second) ;
                    }
               }
         }
      return return_attribute;
   }


void EasyStorage <AstAttributeMechanism*> :: arrangeMemoryPoolInOneBlock()
   {
  // call suitable methods of parent and members
     StorageClassMemoryManagement < EasyStorageMapEntry<std::string,AstAttribute*> > :: arrangeMemoryPoolInOneBlock();
     EasyStorageMapEntry<std::string,AstAttribute*> :: arrangeMemoryPoolInOneBlock();
   }


void EasyStorage <AstAttributeMechanism*> :: deleteMemoryPool()
   {
  // call suitable methods of parent and members
     StorageClassMemoryManagement < EasyStorageMapEntry<std::string,AstAttribute*> > :: deleteMemoryPool();
     EasyStorageMapEntry<std::string,AstAttribute*> :: deleteMemoryPool();
   }


void EasyStorage <AstAttributeMechanism*> :: writeToFile(std::ofstream& outputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::writeMarker("|07|",outputFileStream);
#endif
  // call suitable methods of parent and members
     StorageClassMemoryManagement < EasyStorageMapEntry<std::string,AstAttribute*> > :: writeToFile(outputFileStream);
     EasyStorageMapEntry<std::string,AstAttribute*> :: writeToFile(outputFileStream);
   }


void EasyStorage <AstAttributeMechanism*> :: readFromFile (std::ifstream& inputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::readMarker("|07|",inputFileStream);
#endif
  // call suitable methods of parent and members
     StorageClassMemoryManagement < EasyStorageMapEntry<std::string,AstAttribute*> > :: readFromFile (inputFileStream);
     EasyStorageMapEntry<std::string,AstAttribute*> :: readFromFile (inputFileStream);
   }


/*
   ****************************************************************************************
   **      Implementations for EasyStorage <PreprocessingInfo*>                          **
   ****************************************************************************************
*/
void EasyStorage<PreprocessingInfo*> :: storeDataInEasyStorageClass(PreprocessingInfo* info)
   {
     typedef StorageClassMemoryManagement <char> Base;
  // get changeable pointer
     char* copy_ = info->packed();
     long offset = Base::setPositionAndSizeAndReturnOffset ( info->packed_size() ) ;
  // if the new data does not fit in the actual block
     if (0 < offset)
        {
       // if there is still space in the actual block
          if ( offset < Base::getSizeOfData()   && Base::actual != NULL )
             {
               memcpy( Base::actual, copy_, (Base::getSizeOfData()-offset)*sizeof(char) );
               copy_ += (Base::getSizeOfData()-offset);
             }
      // the data does not fit in one block
          while (Base::blockSize < (unsigned long)(offset))
             {
               Base::actual = Base::getNewMemoryBlock();
               memcpy(Base::actual, copy_, Base::blockSize*sizeof(char) );
               offset -= Base::blockSize;
               copy_ += Base::blockSize;
             };
       // put the rest of the data in a new memory block
          Base::actual = Base::getNewMemoryBlock();
          memcpy(Base::actual, copy_, offset*sizeof(char) );
          Base::actual += offset;
        }
     else
        {
       // put the the data in the memory block
          memcpy(Base::actual, copy_, Base::getSizeOfData()*sizeof(char) );
          Base::actual += Base::getSizeOfData();
        }
   }


PreprocessingInfo* EasyStorage<PreprocessingInfo*> :: rebuildDataStoredInEasyStorageClass()
   {
     typedef StorageClassMemoryManagement <char> Base;
      assert ( this != NULL );
      PreprocessingInfo* returnInfo  = NULL;
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
      assert ( Base::actualBlock <= 1 );
      assert ( (0 < Base::getSizeOfData() && Base::actual!= NULL) || ( Base::getSizeOfData() <= 0 ) );
#endif
      if ( 0 < Base::getSizeOfData() )
         {
           returnInfo = new PreprocessingInfo;
        // if there is any data in the pool at all
           if ( Base::actual != NULL  && 0 < Base::getSizeOfData() )
              {
                char* data_ = new char[Base::getSizeOfData()];
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
                assert ( Base::memoryBlockList != NULL );
                assert ( Base::actualBlock == 1 );
#endif
                memcpy(data_, Base::getBeginningOfDataBlock(), Base::getSizeOfData() * sizeof(char) );
                returnInfo->unpacked( data_ );
              }
         }
      return returnInfo;
   }

void EasyStorage <PreprocessingInfo*> :: arrangeMemoryPoolInOneBlock()
   {
  // call suitable methods of parent and members
     StorageClassMemoryManagement < char > :: arrangeMemoryPoolInOneBlock();
   }


void EasyStorage <PreprocessingInfo*> :: deleteMemoryPool()
   {
  // call suitable methods of parent and members
     StorageClassMemoryManagement < char > :: deleteMemoryPool();
   }


void EasyStorage <PreprocessingInfo*> :: writeToFile(std::ofstream& outputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::writeMarker("|17|",outputFileStream);
#endif
  // call suitable methods of parent and members
     StorageClassMemoryManagement < char > :: writeToFile(outputFileStream);
   }


void EasyStorage <PreprocessingInfo*> :: readFromFile (std::ifstream& inputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::readMarker("|17|",inputFileStream);
#endif
  // call suitable methods of parent and members
     StorageClassMemoryManagement < char > :: readFromFile (inputFileStream);
   }



/*
   ****************************************************************************************
   **       Implementations for asyStorage <std::vector<PreprocessingInfo*> >            **
   ****************************************************************************************
*/
void EasyStorage <std::vector<PreprocessingInfo*> > :: storeDataInEasyStorageClass(const std::vector<PreprocessingInfo*>& data_)
   {
     typedef StorageClassMemoryManagement<EasyStorage<PreprocessingInfo*> > Base;
  // get iterator pointing to begin
     std::vector<PreprocessingInfo*>::const_iterator copy_ = data_.begin();
     long offset = Base::setPositionAndSizeAndReturnOffset ( data_.size() ) ;
  // if the new data does not fit in the actual block
     if (0 < offset)
        { 
       // if there is still space in the actual block
          if ( offset < Base::getSizeOfData() && Base::actual != NULL )
             { 
               for (;(unsigned long)( Base::actual - Base::getBeginningOfActualBlock()) < Base::blockSize; ++Base::actual, ++copy_)
                  {
                    Base::actual->storeDataInEasyStorageClass(*copy_);
                  }
             }
      // the data does not fit in one block
          while (Base::blockSize < (unsigned long)(offset))
             {
               Base::actual = Base::getNewMemoryBlock();
               for (; (unsigned long)(Base::actual - Base::getBeginningOfActualBlock()) < Base::blockSize; ++Base::actual, ++copy_)
                  {
                    Base::actual->storeDataInEasyStorageClass(*copy_);
                  }
               offset -= Base::blockSize;
             };
       // get a new memory block
          Base::actual = Base::getNewMemoryBlock();
        }
  // put (the rest of) the data in a new memory block
    for ( ; copy_ != data_.end(); ++copy_, ++Base::actual )
        {
          Base::actual->storeDataInEasyStorageClass(*copy_);
        }
   }


std::vector<PreprocessingInfo*> 
EasyStorage <std::vector<PreprocessingInfo*> > :: rebuildDataStoredInEasyStorageClass()
   {
     typedef StorageClassMemoryManagement<EasyStorage<PreprocessingInfo*> > Base;
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
      assert ( Base::actualBlock <= 1 );
      assert ( (0 < Base::getSizeOfData() && Base::actual!= NULL) || ( Base::getSizeOfData() == 0 ) );
#endif
      std::vector<PreprocessingInfo*> data_;
   // if there is any data in the pool
      if ( Base::actual != NULL  && 0 < Base::getSizeOfData() )
         {
           EasyStorage<PreprocessingInfo*> *pointer = Base::getBeginningOfDataBlock() ;
           for ( long i=0; i < Base::getSizeOfData(); ++i )
              {
                data_.push_back( (pointer+i)->rebuildDataStoredInEasyStorageClass() );
              }
         }
      return data_;
   }

void EasyStorage <std::vector<PreprocessingInfo*> > :: arrangeMemoryPoolInOneBlock()
   {
    // calling the base class method
     StorageClassMemoryManagement<EasyStorage<PreprocessingInfo*> > :: arrangeMemoryPoolInOneBlock();
    // calling the basic type 
     EasyStorage <PreprocessingInfo*> :: arrangeMemoryPoolInOneBlock(); 
   }

void EasyStorage <std::vector<PreprocessingInfo*> > :: deleteMemoryPool() 
   {
    // calling the base class method
     StorageClassMemoryManagement<EasyStorage<PreprocessingInfo*> > :: deleteMemoryPool(); 
    // calling the basic type 
     EasyStorage <PreprocessingInfo*> :: deleteMemoryPool(); 
   }


void EasyStorage <std::vector<PreprocessingInfo*> > :: writeToFile(std::ofstream& outputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::writeMarker("|08|",outputFileStream);
#endif
    // calling the base class method
     StorageClassMemoryManagement<EasyStorage<PreprocessingInfo*> > :: writeToFile(outputFileStream);
    // calling the basic type 
     EasyStorage <PreprocessingInfo*> ::  writeToFile(outputFileStream); 
   }

void EasyStorage <std::vector<PreprocessingInfo*> > :: readFromFile (std::ifstream& inputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::readMarker("|08|",inputFileStream);
#endif
    // calling the base class method
     StorageClassMemoryManagement<EasyStorage<PreprocessingInfo*> > :: readFromFile (inputFileStream);
    // calling the basic type 
     EasyStorage <PreprocessingInfo*> ::  readFromFile (inputFileStream); 
   }



/*
   ****************************************************************************************
   **      Implementations for EasyStorage <ROSEAttributesList>                          **
   ****************************************************************************************
*/
void EasyStorage<ROSEAttributesList> :: storeDataInEasyStorageClass ( ROSEAttributesList* info)
   {
  // call suitable methods on members
     preprocessingInfoVector.storeDataInEasyStorageClass( info->getList() );
     fileNameString.storeDataInEasyStorageClass( info->getFileName() );
     index = info->getIndex() ;
   }


ROSEAttributesList* EasyStorage<ROSEAttributesList> :: rebuildDataStoredInEasyStorageClass()
   {
  // call suitable methods on members
     ROSEAttributesList* returnInfo = new ROSEAttributesList;
     returnInfo->getList() = preprocessingInfoVector.rebuildDataStoredInEasyStorageClass() ;
     returnInfo->setFileName( fileNameString.rebuildDataStoredInEasyStorageClass() ) ;
     returnInfo->setIndex ( index ) ;
     return returnInfo;
   }


void EasyStorage<ROSEAttributesList> :: arrangeMemoryPoolInOneBlock()
   {
  // call suitable methods on members
      EasyStorage < vector<PreprocessingInfo*> > :: arrangeMemoryPoolInOneBlock();
      EasyStorage < std::string > :: arrangeMemoryPoolInOneBlock();
   }


void EasyStorage<ROSEAttributesList> :: deleteMemoryPool()
   {
  // call suitable methods on members
     EasyStorage < vector<PreprocessingInfo*> > :: deleteMemoryPool();
     EasyStorage < std::string > :: deleteMemoryPool();
   }


void EasyStorage<ROSEAttributesList> :: writeToFile(std::ofstream& outputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::writeMarker("|09|",outputFileStream);
#endif
  // call suitable methods on members
      EasyStorage < vector<PreprocessingInfo*> > :: writeToFile(outputFileStream);
      EasyStorage < std::string > :: writeToFile(outputFileStream);
   }


void EasyStorage<ROSEAttributesList> :: readFromFile (std::ifstream& inputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::readMarker("|09|",inputFileStream);
#endif
  // call suitable methods on members
     EasyStorage < vector<PreprocessingInfo*> > :: readFromFile (inputFileStream);
     EasyStorage < std::string > :: readFromFile (inputFileStream);
   }


/*
   ****************************************************************************************
   **      Implementations for EasyStorage ROSEAttributesListContainerPtr>               **
   ****************************************************************************************
*/
void EasyStorage <ROSEAttributesListContainerPtr> :: storeDataInEasyStorageClass(const vector<ROSEAttributesList*>& data_)
   {
     typedef StorageClassMemoryManagement< EasyStorage<ROSEAttributesList> > Base;
     std::vector<ROSEAttributesList*>::const_iterator dat = data_.begin();
     long offset = Base::setPositionAndSizeAndReturnOffset ( data_.size() ) ;
  // if the new data does not fit in the actual block
     if (0 < offset)
        {
       // if there is still space in the actual block
          if (offset < Base::getSizeOfData())
             {
               if (Base::actual != NULL)
                  {
                    for (; (unsigned long)(Base::actual - Base::getBeginningOfActualBlock()) < Base::blockSize; ++Base::actual, ++dat)
                       {
                         Base::actual->storeDataInEasyStorageClass(*dat);
                       }
                  }
             }
       // the data does not fit in one block
          while (Base::blockSize < (unsigned long)(offset))
             {
               Base::actual = Base::getNewMemoryBlock();
               for (; (unsigned long)(Base::actual - Base::getBeginningOfActualBlock()) < Base::blockSize; ++Base::actual, ++dat)
                  {
                    Base::actual->storeDataInEasyStorageClass(*dat);
                  }
               offset -= Base::blockSize;
             };
          Base::actual = Base::getNewMemoryBlock();
        }
     for (; dat != data_.end(); ++dat, ++Base::actual)
        {
          Base::actual->storeDataInEasyStorageClass(*dat);
        }
   }


std::vector<ROSEAttributesList*> 
EasyStorage <ROSEAttributesListContainerPtr> :: rebuildDataStoredInEasyStorageClass()
   {
     typedef StorageClassMemoryManagement< EasyStorage<ROSEAttributesList> > Base;
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
      assert ( Base::actualBlock <= 1 );
      assert ( (0 < Base::getSizeOfData() && Base::actual!= NULL) || ( Base::getSizeOfData() <= 0 ) );
#endif
      vector<ROSEAttributesList*> data_;
   // if the memory pool is valid 
      if ( Base::actual != NULL && 0 < Base::getSizeOfData() )
         {
           EasyStorage<ROSEAttributesList>* pointer = Base::getBeginningOfDataBlock();
           for ( long i=0; i < Base::getSizeOfData(); ++i )
              {
                data_.push_back((pointer+i)->rebuildDataStoredInEasyStorageClass() );
              }
         }
      return data_;
   }


void EasyStorage <ROSEAttributesListContainerPtr> :: arrangeMemoryPoolInOneBlock()
   {
  // call suitable methods on members and base class
      StorageClassMemoryManagement< EasyStorage<ROSEAttributesList> >:: arrangeMemoryPoolInOneBlock();
      EasyStorage<ROSEAttributesList> :: arrangeMemoryPoolInOneBlock();
   }


void EasyStorage <ROSEAttributesListContainerPtr> :: deleteMemoryPool()
   {
  // call suitable methods on members and base class
     StorageClassMemoryManagement< EasyStorage<ROSEAttributesList> > :: deleteMemoryPool();
     EasyStorage<ROSEAttributesList> :: deleteMemoryPool();
   }


void EasyStorage <ROSEAttributesListContainerPtr> :: writeToFile(std::ofstream& outputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::writeMarker("|10|",outputFileStream);
#endif
  // call suitable methods on members and base class
      StorageClassMemoryManagement< EasyStorage<ROSEAttributesList> >:: writeToFile(outputFileStream);
      EasyStorage<ROSEAttributesList> :: writeToFile(outputFileStream);
   }


void EasyStorage <ROSEAttributesListContainerPtr> :: readFromFile (std::ifstream& inputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::readMarker("|10|",inputFileStream);
#endif
  // call suitable methods on members and base class
     StorageClassMemoryManagement< EasyStorage<ROSEAttributesList> > :: readFromFile (inputFileStream);
     EasyStorage<ROSEAttributesList> :: readFromFile (inputFileStream);
   }



/*
   ****************************************************************************************
   **      Implementations for <EasyStorageMapEntry <std::string,int>                    **
   ****************************************************************************************
*/
// Is not inherited from StorageClassMemoryManagement
void EasyStorageMapEntry <std::string,int> :: storeDataInEasyStorageClass(const std::pair<std::string, const int >& iter)
   {
     nameString.storeDataInEasyStorageClass(iter.first);
     index = iter.second;
   }

std::pair<std::string, int > EasyStorageMapEntry <std::string,int> :: rebuildDataStoredInEasyStorageClass()
   {
     std::pair<std::string,int> returnPair(nameString.rebuildDataStoredInEasyStorageClass(),index);
     return returnPair;
   }

void EasyStorageMapEntry <std::string,int> :: arrangeMemoryPoolInOneBlock() 
   {
     EasyStorage <std::string> :: arrangeMemoryPoolInOneBlock();
   }
  
void EasyStorageMapEntry <std::string,int> :: deleteMemoryPool() 
   {
     EasyStorage <std::string> :: deleteMemoryPool();
   }


void EasyStorageMapEntry <std::string,int> :: writeToFile(std::ofstream& outputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::writeMarker("|11|",outputFileStream);
#endif
     EasyStorage <std::string> :: writeToFile(outputFileStream);
   }
  
void EasyStorageMapEntry <std::string,int> :: readFromFile (std::ifstream& inputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::readMarker("|11|",inputFileStream);
#endif
     EasyStorage <std::string> :: readFromFile (inputFileStream);
   }



/*
   ****************************************************************************************
   **      Implementations for EasyStorageMapEntry <int, std::string>                    **
   ****************************************************************************************
*/
// Is not inherited from StorageClassMemoryManagement
void EasyStorageMapEntry <int, std::string> :: storeDataInEasyStorageClass(const std::pair<const int, std::string>& iter)
   {
     index = iter.first;
     nameString.storeDataInEasyStorageClass(iter.second);
   }

std::pair<int, std::string> EasyStorageMapEntry <int, std::string> :: rebuildDataStoredInEasyStorageClass()
   {
     std::pair<int, std::string> returnPair(index, nameString.rebuildDataStoredInEasyStorageClass());
     return returnPair;
   }

void EasyStorageMapEntry <int, std::string> :: arrangeMemoryPoolInOneBlock() 
   {
     EasyStorage <std::string> :: arrangeMemoryPoolInOneBlock();
   }
  
void EasyStorageMapEntry <int, std::string> :: deleteMemoryPool() 
   {
     EasyStorage <std::string> :: deleteMemoryPool();
   }


void EasyStorageMapEntry <int,std::string> :: writeToFile(std::ofstream& outputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::writeMarker("|12|",outputFileStream);
#endif
     EasyStorage <std::string> :: writeToFile(outputFileStream);
   }
  
void EasyStorageMapEntry <int,std::string> :: readFromFile (std::ifstream& inputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::readMarker("|12|",inputFileStream);
#endif
     EasyStorage <std::string> :: readFromFile (inputFileStream);
   }



/*
   ****************************************************************************************
   **      Implementations for EasyStorage < std::map<int,std::string> >                 **
   ****************************************************************************************
*/
void EasyStorage < std::map<int,std::string> > :: storeDataInEasyStorageClass(const std::map<int,std::string>& data_) 
   {
     typedef StorageClassMemoryManagement< EasyStorageMapEntry<int, std::string> > Base;
     std::map<int,std::string>::const_iterator dat = data_.begin();
     long offset = Base::setPositionAndSizeAndReturnOffset ( data_.size() ) ;
  // if the new data does not fit in the actual block
     if (0 < offset)
        {
       // if there is still space in the actual block
          if (offset < Base::getSizeOfData())
             {
               if (Base::actual != NULL)
                  {
                    for (; (unsigned long)(Base::actual - Base::getBeginningOfActualBlock()) < Base::blockSize; ++Base::actual, ++dat)
                       {
                         Base::actual->storeDataInEasyStorageClass(*dat);
                       }
                  }
             }
       // the data does not fit in one block
          while (Base::blockSize < (unsigned long)(offset))
             {
               Base::actual = Base::getNewMemoryBlock();
               for (; (unsigned long)(Base::actual - Base::getBeginningOfActualBlock()) < Base::blockSize; ++Base::actual, ++dat)
                  {
                    Base::actual->storeDataInEasyStorageClass(*dat);
                  }
               offset -= Base::blockSize;
             };
          Base::actual = Base::getNewMemoryBlock();
        }
     for (; dat != data_.end(); ++dat, ++Base::actual)
        {
          Base::actual->storeDataInEasyStorageClass(*dat);
        }
   }

std::map<int,std::string> 
EasyStorage < std::map<int,std::string> > :: rebuildDataStoredInEasyStorageClass()
   {
     typedef StorageClassMemoryManagement< EasyStorageMapEntry<int, std::string> > Base;
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
      assert ( Base::actualBlock <= 1 );
      assert ( (0 < Base::getSizeOfData() && Base::actual!= NULL) || ( Base::getSizeOfData() <= 0 ) );
#endif
      std::map<int,std::string> data_;
   // if the memory pool is valid
      std::pair <int, std::string> tempPair;
      if ( Base::actual != NULL && 0 < Base::getSizeOfData() )
         {
           EasyStorageMapEntry<int,std::string>* pointer = Base::getBeginningOfDataBlock();
           for ( long i=0; i < Base::getSizeOfData(); ++i )
              {
                assert (Base::actualBlock == 1);
                tempPair = (pointer+i)->rebuildDataStoredInEasyStorageClass();
                data_[tempPair.first] = tempPair.second;
              }
         }
      return data_;

   }

void EasyStorage < std::map<int,std::string> > :: arrangeMemoryPoolInOneBlock()
   {
     StorageClassMemoryManagement< EasyStorageMapEntry<int, std::string> > :: arrangeMemoryPoolInOneBlock();
     EasyStorageMapEntry<int, std::string> :: arrangeMemoryPoolInOneBlock();
   }

void EasyStorage < std::map<int,std::string> > :: deleteMemoryPool()
   {
     StorageClassMemoryManagement< EasyStorageMapEntry<int, std::string> > :: deleteMemoryPool();
     EasyStorageMapEntry<int, std::string> :: deleteMemoryPool();
   }


void EasyStorage < std::map<int,std::string> > :: writeToFile(std::ofstream& outputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::writeMarker("|13|",outputFileStream);
#endif
     StorageClassMemoryManagement< EasyStorageMapEntry<int, std::string> > :: writeToFile(outputFileStream);
     EasyStorageMapEntry<int, std::string> :: writeToFile(outputFileStream);
   }

void EasyStorage < std::map<int,std::string> > :: readFromFile (std::ifstream& inputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::readMarker("|13|",inputFileStream);
#endif
     StorageClassMemoryManagement< EasyStorageMapEntry<int, std::string> > :: readFromFile (inputFileStream);
     EasyStorageMapEntry<int, std::string> :: readFromFile (inputFileStream);
   }




/*
   ****************************************************************************************
   **      Implementations for EasyStorage < std::map<std::string,int> >                 **
   ****************************************************************************************
*/
void EasyStorage < std::map<std::string,int> > :: storeDataInEasyStorageClass(const std::map<std::string,int>& data_) 
   {
     typedef StorageClassMemoryManagement< EasyStorageMapEntry<std::string,int> > Base;
     std::map<std::string,int>::const_iterator dat = data_.begin();
     long offset = Base::setPositionAndSizeAndReturnOffset ( data_.size() ) ;
  // if the new data does not fit in the actual block
     if (0 < offset)
        {
       // if there is still space in the actual block
          if (offset < Base::getSizeOfData())
             {
               if (Base::actual != NULL)
                  {
                    for (; (unsigned long)(Base::actual - Base::getBeginningOfActualBlock()) < Base::blockSize; ++Base::actual, ++dat)
                       {
                         Base::actual->storeDataInEasyStorageClass(*dat);
                       }
                  }
             }
       // the data does not fit in one block
          while (Base::blockSize < (unsigned long)(offset))
             {
               Base::actual = Base::getNewMemoryBlock();
               for (; (unsigned long)(Base::actual - Base::getBeginningOfActualBlock()) < Base::blockSize; ++Base::actual, ++dat)
                  {
                    Base::actual->storeDataInEasyStorageClass(*dat);
                  }
               offset -= Base::blockSize;
             };
          Base::actual = Base::getNewMemoryBlock();
        }
     for (; dat != data_.end(); ++dat, ++Base::actual)
        {
          Base::actual->storeDataInEasyStorageClass(*dat);
        }
   }

std::map<std::string,int> EasyStorage < std::map<std::string,int> > :: rebuildDataStoredInEasyStorageClass()
   {
     typedef StorageClassMemoryManagement< EasyStorageMapEntry<std::string,int> > Base;
#if STORAGE_CLASS_MEMORY_MANAGEMENT_CHECK
      assert ( Base::actualBlock <= 1 );
      assert ( (0 < Base::getSizeOfData() && Base::actual!= NULL) || ( Base::getSizeOfData() <= 0 ) );
#endif
      std::map<std::string,int> data_;
   // if the memory pool is valid
      if ( Base::actual != NULL && 0 < Base::getSizeOfData() )
         {
           std::pair<std::string,int> tempPair;
           EasyStorageMapEntry<std::string,int>* pointer = Base::getBeginningOfDataBlock();
           for ( long i=0; i < Base::getSizeOfData(); ++i )
              {
                assert (Base::actualBlock == 1);
                tempPair = (pointer+i)->rebuildDataStoredInEasyStorageClass();
                data_[tempPair.first] = tempPair.second;
              }
         }
      return data_;

   }

void EasyStorage < std::map<std::string,int> > :: arrangeMemoryPoolInOneBlock()
   {
     StorageClassMemoryManagement< EasyStorageMapEntry<std::string, int> >:: arrangeMemoryPoolInOneBlock();
     EasyStorageMapEntry<std::string,int> :: arrangeMemoryPoolInOneBlock();
   }

void EasyStorage < std::map<std::string,int> > :: deleteMemoryPool()
   {
     StorageClassMemoryManagement< EasyStorageMapEntry<std::string, int> > :: deleteMemoryPool();
     EasyStorageMapEntry<std::string,int> :: deleteMemoryPool();
   }

void EasyStorage < std::map<std::string,int> > :: writeToFile(std::ofstream& outputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::writeMarker("|14|",outputFileStream);
#endif
     StorageClassMemoryManagement< EasyStorageMapEntry<std::string, int> >:: writeToFile(outputFileStream);
     EasyStorageMapEntry<std::string,int> :: writeToFile(outputFileStream);
   }

void EasyStorage < std::map<std::string,int> > :: readFromFile (std::ifstream& inputFileStream)
   {
#if FILE_IO_MARKER
     AST_FILE_IO_MARKER::readMarker("|14|",inputFileStream);
#endif
     StorageClassMemoryManagement< EasyStorageMapEntry<std::string, int> > :: readFromFile (inputFileStream);
     EasyStorageMapEntry<std::string,int> :: readFromFile (inputFileStream);
   }

