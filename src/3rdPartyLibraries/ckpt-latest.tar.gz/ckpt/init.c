#include "sys.h"
#include "ckptimpl.h"

void
_init()
{
	ckpt_init();
}
