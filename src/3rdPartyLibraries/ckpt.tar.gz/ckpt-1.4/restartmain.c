#include <stdio.h>
#include <string.h>
#include "ckpt.h"

int
main(int argc, char *argv[])
{
	get_options_argv(argc, argv);
	restart();
	return 1;
}
