#include <stdio.h>
#include "ckpt.h"

void _init() {
	ckpt_init();
}
