#include <unistd.h>
#include <dlfcn.h>
#include <errno.h>
#include <stdio.h>

int
xread(int sd, void *buf, size_t len)
{
	char *p = (char *)buf;
	size_t nrecv = 0;
	ssize_t rv;
	
	while (nrecv < len) {
		rv = read(sd, p, len - nrecv);
		if (0 > rv && errno == EINTR)
			continue;
		if (0 > rv)
			return -1;
		if (0 == rv)
			return 0;
		nrecv += rv;
		p += rv;
	}
	return nrecv;
}

int
xwrite(int sd, const void *buf, size_t len)
{
	char *p = (char *)buf;
	size_t nsent = 0;
	ssize_t rv;
	
	while (nsent < len) {
		rv = write(sd, p, len - nsent);
		if (0 > rv && (errno == EINTR || errno == EAGAIN))
			continue;
		if (0 > rv)
			return -1;
		nsent += rv;
		p += rv;
	}
	return nsent;
}

void
call_if_present(char *name, char *lib)
{
	void *h;
	void (*f)();
	h = dlopen(lib, RTLD_NOW);
	if (!h)
		return;
	f = dlsym(h, name);
	if (!f)
		return;
	f();
}
