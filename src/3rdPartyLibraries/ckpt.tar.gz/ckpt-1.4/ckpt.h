#include <setjmp.h>
#include <linux/unistd.h>
#include <asm/ldt.h>

void ckpt_init();

/* FORMAT OF CHECKPOINT IMAGES:

   ckpt_header
   array of memregion_t (ckpt_header.num_regions count)
   address space pages in order of memregion_t array
*/

#define DEBUG		0

/* See /usr/src/linux/include/asm-i386/linux/page.h */
#define PAGE_SHIFT	12
#define PAGE_SIZE	(1UL << PAGE_SHIFT)
#define PAGE_MASK	(~(PAGE_SIZE-1))

   
struct ckpt_header {
	char cmd[1024];    /* command name for ps and /proc */
	int num_regions;
	jmp_buf jbuf;
	unsigned long brk;

	/* thread-local storage state */
#ifndef PRENPTL
	struct modify_ldt_ldt_s tls; /* tls segment descriptor */
	unsigned long gs;            /* gs register */
#endif
};

/* Maximum number of noncontiguous regions of memory. */
#define MAXREGIONS   512
#define REGION_HEAP  0x8 /* Not equal to any of PROT_* */
typedef struct memregion {
	unsigned long addr;
	unsigned long len;
	/* From mmap, use PROT_EXEC, PROT_READ, PROT_WRITE, PROT_NONE.
           Also REGION_HEAP */
	unsigned flags;
} memregion_t;

struct ckpt_restore {
	int fd;
	struct ckpt_header head;
	unsigned long argv0; /* address of argv[0] */
	memregion_t orig_regions[MAXREGIONS];
};

/* mem.c */
void heap_extension(memregion_t *region);
int read_self_regions(memregion_t *regions, int *num_regions);
void print_regions(const memregion_t *regions, int num_regions, const char *msg);
int map_orig_regions(const struct ckpt_restore *restbuf);
int addr_in_regions(unsigned long addr, const memregion_t *regions, int num_regions);
int set_writeable(const memregion_t *regions, int num_regions);
int set_orig_mprotect(const memregion_t *orig, int num_orig);
int call_with_new_stack(unsigned long num_pages,
			const memregion_t *verboten,
			int num_verboten,
			void(*fn)(void));
int unmap_ifnot_orig(const memregion_t *orig, int num_orig);

/* signal.c */
int ckpt_signals();
int restore_signals();

/* util.c */
int xwrite(int sd, const void *buf, size_t len);
int xread(int sd, void *buf, size_t len);
void call_if_present(char *name, char *lib);

/* csclt.c */
int request_ckpt_save(char *serveraddr,  char *id);
int request_ckpt_restore(char *serveraddr, char *id);
int request_ckpt_remove(char *serveraddr, char *id);
int request_ckpt_access(char *serveraddr, char *id);

/* restart.c */
void restart();

/* options.c */
struct options {
	char *ckpt_id;
	char *ckpt_restartlib;
	char *ckpt_server;
	char *ckpt_filename;
	int ckpt_signal;
	int ckpt_continue;
};
extern struct options OPTIONS;
void get_options();
void get_options_argv(int argc, char *argv[]);

/* FIXME: We use this address to guess which
   pages belong to the stack. */
enum {
	STACKHACK = 0xb0000000
};

void getfds(void *);
void restore_fds(void *ignored);
