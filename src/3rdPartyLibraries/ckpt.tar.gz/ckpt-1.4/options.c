#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <signal.h>
#include <time.h>
#include "ckpt.h"

struct options OPTIONS;

static void
defaults(struct options *opt)
{
	static char default_id[9];
	/* FIXME: weak ckpt id generator; also
	   may break programs that use the seed */
	srand(time(NULL));
	sprintf(default_id, "%08x", rand());
	opt->ckpt_id = default_id;
	opt->ckpt_restartlib = "librestart.so";
	opt->ckpt_server = NULL;
	opt->ckpt_filename = NULL;
	opt->ckpt_signal = SIGTSTP;
	opt->ckpt_continue = 0;
}

struct sigmap_t {
	char *name;
	int num;
};

static struct sigmap_t map[] = {
	{ "SIGHUP",     SIGHUP    },
	{ "SIGINT",     SIGINT    },
	{ "SIGQUIT",    SIGQUIT   },
	{ "SIGILL",     SIGILL    },
	{ "SIGTRAP",    SIGTRAP   },
	{ "SIGABRT",    SIGABRT   },
	{ "SIGIOT",     SIGIOT    },
	{ "SIGBUS",     SIGBUS    },
	{ "SIGFPE",     SIGFPE    },
	{ "SIGKILL",    SIGKILL   },
	{ "SIGUSR1",    SIGUSR1   },
	{ "SIGSEGV",    SIGSEGV   },
	{ "SIGUSR2",    SIGUSR2   },
	{ "SIGPIPE",    SIGPIPE   },
	{ "SIGALRM",    SIGALRM   },
	{ "SIGTERM",    SIGTERM   },
	{ "SIGSTKFLT",  SIGSTKFLT },
	{ "SIGCLD",     SIGCLD    },
	{ "SIGCHLD",    SIGCHLD   },
	{ "SIGCONT",    SIGCONT   },
	{ "SIGSTOP",    SIGSTOP   },
	{ "SIGTSTP",    SIGTSTP   },
	{ "SIGTTIN",    SIGTTIN   },
	{ "SIGTTOU",    SIGTTOU   },
	{ "SIGURG",     SIGURG    },
	{ "SIGXCPU",    SIGXCPU   },
	{ "SIGXFSZ",    SIGXFSZ   },
	{ "SIGVTALRM",  SIGVTALRM },
	{ "SIGPROF",    SIGPROF   },
	{ "SIGWINCH",   SIGWINCH  },
	{ "SIGPOLL",    SIGPOLL   },
	{ "SIGIO",      SIGIO     },
	{ "SIGPWR",     SIGPWR    },
	{ "SIGSYS",     SIGSYS    },
	{ NULL, 0 }
};

static int
mapsig(char *s)
{
	struct sigmap_t *p;
	p = map;
	while (p->name) {
		if (!strcmp(p->name, s))
			return p->num;
		p++;
	}
	return -1;
}

static char *
replace_ckptid(char *n, char *id)
{
	int i;
	int lenn;
	int lenid;
	int numid = 0;
	char *b, *p, *q;

	lenn = strlen(n);
	for (i = 0; i < lenn-1; i++)
		if (n[i] == '%' && n[i+1] == 'i')
			numid++;
	if (!numid)
		return n;

	lenid = strlen(id);
	b = malloc((lenn+(numid*lenid)+1)*sizeof(char));
	if (!b) {
		fprintf(stderr, "Out of memory\n");
		exit(1);
	}
	p = b;
	q = n;
	while (*q) {
		if (*q == '%' && *(q+1) == 'i') {
			strcpy(p, id);
			p += strlen(id);
			q += 2;
		} else
			*p++ = *q++;
	}
	return b;
}

void
get_options()
{
	char *p;
	defaults(&OPTIONS);
	p = getenv("CKPT_ID");
	if (p) 
		OPTIONS.ckpt_id = p;
	p = getenv("CKPT_SERVER");
	if (p)
		OPTIONS.ckpt_server = p;
	p = getenv("CKPT_FILENAME");
	if (p)
		OPTIONS.ckpt_filename = replace_ckptid(p, OPTIONS.ckpt_id);

	p = getenv("CKPT_CONTINUE");
	if (p)
		OPTIONS.ckpt_continue = 1;
	p = getenv("CKPT_SIGNAL");
	if (p) {
		if (isdigit(p[0]))
			OPTIONS.ckpt_signal = atoi(p);
		else
			OPTIONS.ckpt_signal = mapsig(p);
	}
}

void
get_options_argv(int argc, char *argv[])
{
	get_options();
	if (argc > 1)
		OPTIONS.ckpt_filename = argv[1];
	else {
		fprintf(stderr, "usage: restart CKPTFILE\n");
		exit(1);
	}
}
