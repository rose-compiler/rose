#!/bin/bash

../graph.py -fgnuplot -ocxx_astnodes -x"number of AST nodes" -efilename \
	-ememory -H4 -W4 -P4 --ylabel="Time(seconds)" --average -g75000 \
	-wlines -Fpng -r Cxx_ROSE_PERFORMANCE_DATA.csv

../graph.py -fgnuplot -oc_astnodes -x"number of AST nodes" -efilename \
	-ememory -H4 -W4 -P4 --ylabel="Time(seconds)" --average -g3000 \
	-wlines -Fpng -r C_ROSE_PERFORMANCE_DATA.csv

../graph.py -fgnuplot -ocsubset_astnodes -x"number of AST nodes" -efilename \
	-ememory -H4 -W4 -P4 --ylabel="Time(seconds)" --average -g4000 \
	-wlines -Fpng -r C_subsetOfCxx_ROSE_PERFORMANCE_DATA.csv

../graph.py -fgnuplot -oc99_astnodes -x"number of AST nodes" -efilename \
	-ememory -H4 -W4 -P4 --ylabel="Time(seconds)" -wlines -Fpng -r \
	C99_ROSE_PERFORMANCE_DATA.csv

rm -f *.dat* *.plt

echo "created:"
ls *.png
