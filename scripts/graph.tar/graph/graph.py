#!/usr/bin/env python
#
###############################################################################
#
# Author: Gary Yuan
# Date: 8/24/2006
# File: graph.py
# Purpose: Plots ROSE performance data 
#
###############################################################################

import sys
import os
import string
import getopt
import csv
import math
import stats
from optparse import *


class valueAccumulator:
  """
    class valueAccumulator
	stores the collected lists of data for a particular bin of data

	Data Members:
	values - A list of lists of floats that stores data line-by-line
		from the data file written by generateGraph()
	nValue - The number of lists within the list "values"

	Function Members: see. individual document lines
  """

  def __init__(self,list):
    self.values = []
    self.nValue = 1 
    for i in range(0,len(list)):
      self.values.extend([ [ float(list[i]) ] ])
    return

  def addValues(self,list):
    """Append a new data list to hash key"""
    self.nValue += 1
    for i in range(0,len(list)):
      self.values[i].append( float(list[i]) )
    return

  def averageValues(self):
    """Average of value lists within values of key"""
    average = []
    for value in self.values:
      sum = stats.lsum(value)
      average.append(sum/self.nValue)
    return average

  def stdDev(self):
    """standard deviation of value lists within values of key"""
    deviation = []
    for value in self.values:
      if len(value) > 1:
        deviation.append(stats.lstdev(value))
      else:
	deviation.append(0)
    return deviation

  def stdErr(self):
    """standard error of value lists within values of key"""
    error = []
    for value in self.values:
      if len(value) > 1:
        error.append(stats.lsterr(value))
      else:
	error.append(0)
    return error

  def getMean(self):
    """mean of value lists within values of key"""
    mean = []
    for value in self.values:
      mean.append(stats.lmean(value))
    return mean

  def getMedian(self):
    """median of value lists within values of key"""
    median = []
    for value in self.values:
      median.append(stats.lmedian(value))
    return median

  def getValue(self,index):
    """Return a list within list of lists 'values'"""
    if index < 0 or index > len(values):
      return []
    else:
      return self.values[index]
    # if, error checking for list bounds
    # else, return good index in list of lists "values"



def getRange(num,gran):
  """return the string value of the current data bin"""
  return str(int(round(num/gran)))

#  range = num / gran
#  wRange = int(str(range).split('.')[0])
#  dRange = round(float(str(range).split('.')[1]))
#
#  if dRange > wRange:
#    return str(wRange + 1)
#  else:
#    return str(wRange)



def reEvaluateData(output,ext,gran,separator,bavg,bdev,berr):
  """
    reEvaluateData()
	re-calculate ouput data based on given boolean operations
	bavg, bdev, and berr.

	Arguments:
	output - The output file prefix specified by the -o option
	ext - The default data extension of that output prefix
	gran - The integer granularity provided by option -g
	spearator - The character or string used in delimiting
		the output data file
	bavg - A boolean value tells to calculate average
	bdev - A boolean value tells to calculate standard deviation
	berr - A boolean value tells to calculate standard error

	Variables:
	valueHash - A hash table containing the data bins collected
		in data member valueAccumulator
	rawData - A list of output data split on string separator
	fin - The input file, i.e. the data file generated from
		generateGraph()
	fout - The output file, which overwrites the old file refered to by fin
		but first saves old data file
	line - A string that hold the current line read from fin
	r - The key to the current bin
  """
  valueHash = {}
  rawData = []
  fin = open(output + ext,"r")
  line = fin.readline()

  while line != "":
    rawData = string.strip(line).split(separator)	# read .dat file
    r = getRange(float(rawData[0]),gran)	# get range for key

    if valueHash.has_key(r):
      valueHash[r].addValues(rawData)		# update hash key
    else:
      valueHash[r] = valueAccumulator(rawData)	# initialize new hash key

    line = fin.readline()

  os.rename(output + ext,output + ext + ".old")	# save old data file
  fout = open(output + ext,'a')			# overwrite with new data file
  #fstat = open(output + ".stat",'a')

  for key in valueHash.keys():
    if bavg:
      for avg in valueHash[key].averageValues():
        fout.write(str(avg) + separator)
      # for average

    if bdev:
      for dev in valueHash[key].stdDev()[1:]:
        fout.write(str(dev) + separator)
      # for standard deviation

    if berr:
      for err in valueHash[key].stdErr()[1:]:
        fout.write(str(err) + separator)
      # for standard error

    fout.write('\n')		# format, data output new line

  return

###############################################################################

def getHash(rawData):
  """
    getHash()
	Returns a hash table of (key,value) pairs from the current line of
	input.

	Varialbes:
	rawData - A list of the current line of input split on commas
  """

  hash = dict([ (rawData[i],rawData[i+1]) for i in range(0,len(rawData)-1,2) ])

  return hash

##############################################################################

def generateGraph(reader,fout,xKey,yExclude,yInclude,separator):
  """
    generateGraph()
	Creates the data and script files for input to the plotting application
	specified by the -f option to graph.py.

	Arguments:
	reader - A csv module object that reads input .csv files
	fout - A file output object in mode append
	xKey - The key to serve as the X-Axis coordinates
	yExclude - The key(s) of Y-Axis values to exclude from plot
	yInclude - The key(s) of Y-Axis values to include into plot
	separator - The character or string to serve as the separator for the
		output data file

	Varibles:
	keys - A list of keys actually plotted along the Y-Axis
	data - A temporary string that holds the formatted output of the
		current line of comma-separated input.
  """

  if yInclude != []:
    keys = yInclude	# append to keys list the include values of Y-Axis
  
  for row in reader:
    hash = getHash(row)
    data = ""		# reset the temporary data string

    if yInclude == [] and yExclude != []:
      keys = hash.keys()
      keys.remove(xKey)
    # if, we exclude Y-Axis keys; get a list of all keys in a hash table. All
    # hash tables for a set of files are assumed to be uniform. Then remove
    # the X-Axis key from this list

      for y in yExclude:
        keys.remove(y)	
      # for exclude keys, remove them from keys list

    for key in keys:
      data = data + separator + hash[key]
    # for each key in remaining keys list get the value associated with its
    # key and build a formatted string for data ouput.

    fout.write(hash[xKey] + data + '\n')
    # write the formatted data to file with the first column being the X-Axis
    # coordinate

  return keys	# return the list of keys

###############################################################################

def csv2gnuplot(inputs,output,xKey,yExclude,yInclude,xlabel,ylabel,
		Format,height,width,PointSize,with,
		yMin,yMax,xMin,xMax,bavg,bdev,berr,gran):
  """
    csv2gnuplot()
	Take csv input file(s) and convert them to a data and script file
	specifically for gnuplot.

	Arguments:
	inputs - A list of input files
	output - A string of the output flag specified by the -o option
	xKey - The X-Axis key
	yExclude - A list of keys to exclude from the Y-Axis plot
	yInclude - A list of keys to include into the Y-Axis plot
	xlabel - A string which customizes the name of the X-Axis
	ylabel - A string which customizes the name of the Y-Axis
	Format - The output format for gnuplot, i.e. png
	height - The height size specifier for gnuplot
	width - The width size specifier for gnuplot
	PointSize - The point size specifier for gnuplot
	with - A list of formatting strings to include in the gnuplot "with"
		string
	yMin - The lower limit of the Y-Axis
	yMax - The upper limit of the Y-Axis
	xMin - The lower limit of the X-Axis
	xMax - The upper limit of the X-Axis
	bavg - A boolean value that specifies to average the output data
	berr - A boolean value that specifies to calculate the standard error
		of the output data
	bdev - A boolean value that specifies to calculate the standard deviation
		of the output data
	gran - An integer value to determine the granularity of the data bins

	Variables:
	indices - The count of the number of Y-Axis data columns in the output
		data file
	fout - The output data file to gnuplot, append mode
	fscriptout - The output script file to gnuplot, append mode
	reader - A csv object to read the .csv files in "inputs"
	keys - A list of Y-Axis keys used in the output data file
  """

  indices = 0
  fout = open(output + ".dat",'a')
  
  for i in inputs:
    reader = csv.reader(open(i,'r'),doublequote=True,skipinitialspace=True)
    keys = generateGraph(reader,fout,xKey,yExclude,yInclude,"\t")

  if bdev or berr or bavg:
    reEvaluateData(output,".dat",gran,'\t',bavg,bdev,berr)

  # gnuplot formatting
  index = 0
  fscriptout = open(output + ".plt",'a')
  indices += len(keys)

  while index < indices:
    if with == []:
      if index > 0: 
        fscriptout.write("re")		# replot

      fscriptout.write("plot \"" + output + ".dat" +"\" using 1:" + 
			str(index + 2) + ' ') 
      fscriptout.write("title \"" + keys[index] + "\"" + '\n')
    # default no --with options
    else:
      for w in with:
        if index > 0 or w != with[0]:
	  fscriptout.write("re")	# replot
        if w == "lines":
          fscriptout.write("plot \"" + output + ".dat" +"\" using 1:" + 
			str(index + 2) + ' ') 
          fscriptout.write("smooth csplines ")
          fscriptout.write("title \"" + keys[index] + "\"" + ' ') 
          fscriptout.write("with " + w + '\n')
	# if, with lines
        elif w == "yerrorbars":
          fscriptout.write("plot \"" + output + ".dat" + "\" using 1:" +
			str(index + 2) + ':' + str(index + indices + 2) + ' ') 
          fscriptout.write("title \"" + "Error in " + keys[index] + "\"" + ' ')
          fscriptout.write("with " + w + '\n')
	# else if, with yerrorbars
	else:
	  sys.stderr.write("Warning: Unrecognized --with specifier\n")

    index += 1
  # while

#  if Format != "":
#    fscriptout.write("set terminal " + Format + '\n')
#    fscriptout.write("set output \"" + output + '.' + Format + "\"\n")

  if xMin != "" or xMax != "":
    fscriptout.write("set xrange [" + xMin + ':' + xMax + "]\n")
  # if, set X-Axis domain

  if yMin != "" or yMax != "":
    fscriptout.write("set yrange [" + yMin + ':' + yMax + "]\n") 
  # if, set Y-Axis range
  
  if xlabel != "":
    fscriptout.write("set xlabel \"" + xlabel + "\"\n")
  else:
    fscriptout.write("set xlabel \"" + xKey + "\"\n")
  # if, customize X-Axis title based on command-line option --xlabel="<>"
  # else, customize X-Axis title based on the key string of the X-Axis 

  if ylabel != "":
    fscriptout.write("set ylabel \"" + ylabel + "\"\n")
  # if, customize the Y-Axis title based on command-line option --ylabel="<>"
 
  fscriptout.write("set key below\nset key box\n") 
  fscriptout.write("set size " + width + ',' + height + '\n')
  fscriptout.write("set pointsize " + PointSize + '\n')
  
  if Format != "":
    fscriptout.write("set terminal " + Format + '\n')
    fscriptout.write("set output \"" + output + '.' + Format + "\"\n")
    fscriptout.write("replot\n")
  else:
    fscriptout.write("pause -1\n")
  # if, output format for gnuplot specified replot and output to format
  # else, pause gnuplot program to view the plot

  # end gnuplot formatting

  return
  # cvs2gnuplot()

###############################################################################

def csv2excel(inputs,output,xKey,yExclude,yInclude,bavg,bdev,berr,gran):
  """
    csv2excel()
	Function takes raw csv input and converts to MS Excel csv format

	Arguments:
	inputs - A list of input .csv files
	output - The output string prefix specified by the -o option
	xKey. see csv2gnuplot identical
	...
  """
  fout = open(output + ".csv",'a')

  for i in inputs:
    reader = csv.reader(open(i,'r'),doublequote=True,skipinitialspace=True)
    keys = generateGraph(reader,fout,xKey,yExclude,yInclude,",")
  
  if bdev or berr or bavg:
    reEvaluateData(output,".csv",gran,',',bavg,bdev,berr)

  return

###############################################################################

def csv2matlab(inputs,output,xKey,yExclude,yInclude,xlabel,ylabel,
		height,width,Format,bavg,bdev,berr,gran):
  """
    csv2matlab()
	Take input csv file and convert into matlab data file and .m script
	to plot data in multiple subplots in matlab.

	Arguments:
	see. csv2gnuplot identical

	Varialbes:
	ceilSqrt - An integer value used to calculate the upper limit of
	necessary subplots for matlab
  """

  fout = open(output + ".dat",'a')
  
  # Matlab data
  for i in inputs:
    reader = csv.reader(open(i,'r'),doublequote=True,skipinitialspace=True)
    keys = generateGraph(reader,fout,xKey,yExclude,yInclude,"\t")
  
  if bdev or berr or bavg:
    reEvaluateData(output,".dat",gran,'\t',bavg,bdev,berr)

  # Matlab script
  fscriptout = open(output + ".m",'a')
  index = 2
  ceilSqrt = int(math.ceil(math.sqrt(len(keys))))

  if xlabel == "":
    xlabel = xKey
  # if, no X-Axis title specified make title the xKey

  fscriptout.write("load " + output + ".dat" + '\n')
  fscriptout.write("set(gcf,'position',[0 0 " + str(width) + ' ' + 
			str(height) + "])\n")
  fscriptout.write("x = " + output + "(:,1)\n")

  while index < len(keys) + 2:
    fscriptout.write("y" + str(index) + " = " + output + "(:," 
			+ str(index) + ")\n")
    fscriptout.write("xlabel('" + xlabel + "')\n")
    fscriptout.write("ylabel('" + ylabel + "')\n")
    #fscriptout.write("ylabel('" + keys[index - 2] + "')\n")
    fscriptout.write("subplot(" + str(ceilSqrt) + ',' + str(ceilSqrt) + 
			',' + str(index - 1) + ") ; ")
    fscriptout.write("plot(x,y" + str(index) + ",'o')\n")
    fscriptout.write("legend('" + keys[index - 2] + "')\n")
    index += 1

  if Format != "":
    fscriptout.write("set(gcf,'PaperPositionMode','auto')\n")
    fscriptout.write("print(gcf,'-d" + Format + "'," + '\'' + 
			output + '.' + Format + "')\n")
    fscriptout.write("quit\n")
  # Matlab script

  return

###############################################################################

def removeFiles(output,format):
  """
    removeFiles()
	"safely" remove old files before writing them out again in append mode

	Arguments:
	output - file output prefix specified by -o option
	format - format of output files specified by -f option or default
		 gnuplot

	Variables:
	list - A list of possible extensions of files created by graph.py
  """
  if format == "gnuplot":
    list = [ ".dat", ".plt", ".dat.old" ] 
  elif format == "matlab":
    list = [ ".dat", ".m", ".dat.old" ]
  elif format == "excel":
    list = [ ".csv", ".csv.old" ]
  else:
    sys.stderr.write("Error Unrecognized format <" + format + ">\n")
    sys.exit(1)
    
  for ext in list:
    if os.path.exists(output + ext):
      os.remove(output + ext)

  return

def cmdOptionParse(parser):
  """
    cmdOptionParse():
	Parses command-line arguments and redirects to appropriate functions.

	arguments:
	parser -- a optparse object that stores command-line arguments
  """

  # parse out options and input file arguments
  (options,inputs) = parser.parse_args()
  
  if options.list:
    print "Supported formats:"
    print "1. Gnuplot (.dat .plt) -fgnuplot"
    print "Translate only supported formats:"
    print "1. MS Excel (.csv) -fexcel"
    print "2. Matlab (.dat,.m) -fmatlab"
    sys.exit(0)

  if inputs == []:
    sys.stderr.write("Error: No input file(s) specified\n")
    sys.exit(1)
  # if, print error for no input file(s)

  if options.output != "":
    output = options.output
    removeFiles(output,options.format)
  else:
    sys.stderr.write("Error: No output file name specified\n")
    sys.exit(1)
  # if, output flag specified then remove old files; else raise error

  if options.x == "":
    sys.stderr.write("Error: X-Axis data not specified, please specify with -x\n")
    sys.exit(1)
  # if, error checking

  if options.format == "gnuplot":
    if options.e != [] and options.y != []:
      sys.stderr.write("Error: Options -e and -y may not be used concurrently\n")
      sys.exit(1)

    csv2gnuplot(inputs,output,options.x,options.e,options.y,
		options.xlabel,options.ylabel,options.Format,
		options.Height,options.Width,options.PointSize,
		options.with,options.ymin,options.ymax,
		options.xmin,options.xmax,options.average,options.stddev,
		options.stderr,int(options.granularity))
    # call csv2gnuplot()

    if options.run:
      args = []
      args.append("")
      args.append(output + ".plt")
      os.execvp("gnuplot",args)
    # if run gnuplot
  # if format is gnuplot
  elif options.format == "excel":
    csv2excel(inputs,options.output,options.x,options.e,options.y,
		options.average,options.stddev,options.stderr,
		int(options.granularity))
  elif options.format == "matlab":
    csv2matlab(inputs,options.output,options.x,options.e,options.y,
		options.xlabel,options.ylabel,
		options.Height,options.Width,
		options.Format,options.average,options.stddev,
		options.stderr,int(options.granularity))

    if options.run:
      args = []
      args.append("")
      args.append("-nodesktop")
      args.append("-r")
      args.append(output)
      os.execvp("matlab",args)
  else:
    sys.stderr.write("Error: Unrecognized output format\n")

  return

###############################################################################

def cmdOptionInit(arguments):
  """
    cmdOptionInit():
	Initializes command-line parser optparse object. Specifies which option
	flags behave in what way according to optparse.

	arguments:
	arguments -- sys.argv list of command-line arguments

	variables:
	parser -- optparse, OptionParser()
  """
  parser = OptionParser()

  parser.set_usage("graph.py <input file> [options]")

  parser.add_option("-f","--format",help="Output file format",
			metavar="%FORMAT%",default="gnuplot")
  parser.add_option("-F","--Format",help="Secondard output format",
			metavar="%FORMAT%",default="")
  parser.add_option("-l","--list", help="List supported output formats",
			action="store_true")
  parser.add_option("-o","--output",help="Output file name",metavar="%FILE%",
			default="")
  parser.add_option("-r","--run",help="Run plotting tool",action="store_true")
  parser.add_option("-x",help="X Axis Key Data",metavar="<XKEY>",default="")
  parser.add_option("-y",help="Include Y Axis Data",metavar="<KEY>",
			action="append",default=[])
  parser.add_option("-e",help="Exclude Y Axis Data",metavar="<KEY>",
			action="append",default=[])
  parser.add_option("-g","--granularity",
			help="granularity range for data manipulation",
			metavar="<#>",default="1")
  parser.add_option("-w","--with",help="With lines,points,etc.",
			metavar="%WITH%",default=[],action="append")
  parser.add_option("-H","--Height",help="Output Height default=1",
			metavar="<H#>",default="1")
  parser.add_option("-W","--Width",help="Output Width default=1",
			metavar="<W#>",default="1")
  parser.add_option("-P","--PointSize",help="Set PointSize default=1",
			metavar="<P#>",default="1")
  parser.add_option("--average",help="Average Data over Granularity",
			action="store_true")
  parser.add_option("--stddev",help="Standard Deviation over Granularity",
			action="store_true")
  parser.add_option("--stderr",help="Standard Error over Granularity",
			action="store_true")
  parser.add_option("--xlabel",help="X-Axis Label",metavar="%LABEL%",
			default="")
  parser.add_option("--xmin",help="Minimum X range value",metavar="<#>",
			default="")
  parser.add_option("--xmax",help="Maximum X range value",metavar="<#>",
			default="")
  parser.add_option("--ylabel",help="Y-Axis Label",metavar="%LABEL%",
			default="")
  parser.add_option("--ymin",help="Minimum Y range value",metavar="<#>",
			default="")
  parser.add_option("--ymax",help="Maximum Y range value",metavar="<#>",
			default="")

  return parser

###############################################################################
###############################################################################

parser = cmdOptionInit(sys.argv)
cmdOptionParse(parser)

# control flow: 
# main->cmdOptionInit->main->cmdOptionParse->csv2{}->generateGraph<->getHash()
