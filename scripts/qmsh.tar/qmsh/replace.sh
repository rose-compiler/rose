#!/usr/bin/env bash

if (($# < 4)); then
  echo "Usage: replace.sh <Top Directory> <File Name> <Search String> <Replace String>"
  exit 1
fi

ROOT=$1
FILE=$2
SEARCH=$3
REPLACE=$4
TEMP=.ttemp_hachimitsu

FILELIST=`find $ROOT -name "$FILE"`

for F in $FILELIST
do
  LINENUM=`cat $F | grep -n -e "$SEARCH" | gawk -F: '{print $1}'`
  
  for LINE in $LINENUM
  do
    sed -e "${LINE}c\\${REPLACE}" $F >& $TEMP 
    mv -f $TEMP $F
  done

done
