#!/usr/bin/env bash

###############################################################################
#
# Author: Gary Yuan
# Date: 8/15/2006
# File: addPrereq.sh
# Purpose: Adding prerequisites to QMTest files
#
###############################################################################

addPrereq() {

local count=0		# for loop counter, over arguments
local flag=0		# logical flag to skip over -o <?> option
local testfile=$1	# the test file for modification 
local outcome=$2	# expected outcome
local prevdir=""	# previous working directory
local objects=""	# list of object file(s) or libraries
local prereq=""		# prerequisite test name
local xml_head='<argument name="prerequisites"><set>'
local xml_body=''
local xml_tail="<\/set><\/argument><\/extension>"
local temp=.ttemp_ame_no_ajisai		# temporary file

################################################################################

for arg in $@
do

  ((count++))

  if((count > 3)); then

    if ((flag == 1)); then
      flag=0	# reset flag
      continue
    fi

    case $arg in
      -o) flag=1;; # is the output, i.e. test itself; skip.

      -I* | -L*) echo $arg;;

      -*) continue;; # is argument, continue

      *) objects="${objects} $arg" ;; # append non-option to object list
    esac

  fi # if count > 3 skips over backend compiler

done

################################################################################

for p in $objects
do

  # transform the name of the object file into its' mapped test name
  p=`echo $p | sed -e 's/\./_dot_/g' | sed -e 's/\//_/g' | \
	    gawk '{print tolower($0)}'`

  # perform a find to match the test mapped name and gawk out the prefixed path
  prereq=`find . -name "*$p*" | gawk -F/ '{print $NF}'`
  prereq=${prereq%%.*}

  if [[ $prereq != "" ]]; then
    xml_body="${xml_body}<tuple><text>$prereq<\/text><enumeral>$outcome<\/enumeral><\/tuple>"
  fi # if a prereq is found append it to prerequisites qmtest XML

done

################################################################################

# rewrite the test file with new prerequisite information
sed -e "s/<\/extension>/$xml_head$xml_body$xml_tail/g" $testfile > $temp
mv $temp $testfile
rm -f $temp

}
